// GBA 模拟器实现 — v17
// 实现简化的 ARM7TDMI CPU 和 GBA 外设模拟
//
// 版本历史：
//   v5  : 修复 5 处 CPU/APU 初始问题
//   v6  : 修复 r13_irq 初始化
//   v7  : 修复 Timer ReadIO 实时计数值
//   v8  : 修复 ARM exception return CPSR.T 丢失
//   v9  : 修复 ReadIO 对 IE/IF/IME 未返回实时值
//   v10 : 添加魔术值拦截和深度诊断追踪
//   v11 : 注入 m4aOpenSong 调用（同步阻塞，已被 v12 取代）
//   v12 : 同步注入 → 异步注入
//   v13 : magic 重置修复（但 songPtr trackCount=193 仍早返回）
//   v14 : agbMixer 复制(0x200) + 0x0802E0E8 注入（两项均失败）
//   v15 : EWRAM 扫描找 songPtr(trackCount=13) + agbMixer 复制 0x400
//   v16 : magic 重置修复 + DEBUG 日志精简
//   v17 : [本版本] v16 日志分析 + 四项修复（重复注入/PC追踪/ch偏移修正/Sappy dump）
//
//         v15 测试结论（单项残留失败）：
//           EWRAM 扫描成功找到 songPtr=0x020258CC（trackCount=13，有效）。
//           agbMixer 修复B' 成功：IWRAM[0x03000000]=0x2B007943（非零），
//           PC=0x0300007A 可见 agbMixer 正在执行。
//           但 m4aOpenSong 仍然 27 步早返回，channel 全零：
//             注入时 magic=0x68736D54（SoundDriverMain 在 PC=0x08000EE4 执行
//             0x6003 STR R3,[R0]，将 magic+1 写回，0x53→0x54）。
//             m4aOpenSong 入口读 magic，CMP != 0x68736D53 → BNE 早返回（27步）。
//
//         修复（v16 单项改动）：
//           注入前重置 magic → 0x68736D53
//             在 m4aOpenSong 调用前，若 magic != 0x68736D53，
//             WriteWord(sappyBase, 0x68736D53) 恢复，确保入口检查通过。
//             注：v13 加了此修复但因 songPtr 错误仍失败；v16 songPtr 已正确（EWRAM 扫描），
//             两项同时满足，m4aOpenSong 应完整执行。
//
//         DEBUG 精简（v16）：
//           注释掉已验证功能的日志（LoopTrace/AfterLoop/PostReturn/IWRAMEntry/
//           IWRAM-Write/WriteIO/Timer/DMA基础/LDR追踪/IRQ详细/Frame头/FIFO推送）。
//           保留：[v16]注入流程、[CPU:NOP-SEA]、[CPU:BX-NULL]、channel状态。

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "GbaEmulator.h"
#include "DebugLog.h"
#include <cstring>
#include <algorithm>
#include <stdexcept>
#include <fstream>

// GBA 每帧周期数：280896 (16.78MHz / 59.7275Hz)
#define GBA_CYCLES_PER_FRAME    280896

// v15: m4aOpenSong 异步注入状态（file-scope static，跨帧持久化）
//
// 异步注入流程：
//   WriteWord 检测 EWRAM magic → s_m4aPending=true
//   RunForSamples 主循环顶部：若 pending → 扫描 EWRAM 找歌曲指针 → 修复 agbMixer
//                              → 保存上下文，重定向 PC → m4aOpenSong(songPtr) → s_injecting=true
//   主循环每步执行后：若 injecting 且 execPC==哨兵 → 恢复上下文，s_injecting=false
//
// 关键哨兵：0x02000001（EWRAM 零页，全零=NOP，Thumb bit=1）
//   EWRAM 零页内容全零（0x0000 = Thumb MOVS R0,R0 = NOP），
//   函数执行 BX LR→哨兵 后 CPU 在零页 NOP 海中步进，每步检测到 execPC=0x02000000 则退出
// -----------------------------------------------------------------------
static bool     s_m4aPending   = false;    // SoundDriverInit 完成，等待启动注入
static bool     s_m4aInjected  = false;    // v21：单次注入锁，注入完成后置 true，永久禁止重复注入（防止卡顿）
static bool     s_injecting    = false;    // 当前正在异步执行 m4aOpenSong
static uint32_t s_savedPC      = 0;        // 注入前保存的原 PC（含流水线超前）
static uint32_t s_savedLR      = 0;        // 注入前保存的原 LR
static uint32_t s_savedR0      = 0;        // 注入前保存的 R0
static uint32_t s_savedR2      = 0;        // v18：注入前保存的 R2（注入完成后恢复）
static uint32_t s_step10R2     = 0;        // v18：Step10 R2（候选 mplay 地址）
static uint32_t s_savedCPSR    = 0;        // 注入前保存的 CPSR
static uint32_t s_savedSPSR    = 0;        // 注入前保存的 SPSR
static bool     s_savedHalted  = false;    // 注入前保存的 halted 状态
// s_sappySongPtr 已废弃（v15 改用 EWRAM 扫描方式，动态找有效歌曲指针）
static int      s_injectSteps  = 0;        // 注入执行步数（诊断用）

GbaEmulator::GbaEmulator()
    : m_halted(false)
    , m_outputSampleRate(44100)
    , m_cyclesPerFrame(GBA_CYCLES_PER_FRAME)
    , m_cycleAccum(0)
    , m_lastVcount(0xFF)
    , m_frameCount(0)
    , m_magicAddr(0)
    , m_magicCleared(false)
{
    memset(m_ewram, 0, sizeof(m_ewram));
    memset(m_iwram, 0, sizeof(m_iwram));
    memset(m_ioram, 0, sizeof(m_ioram));
    memset(m_palette, 0, sizeof(m_palette));
    memset(m_vram, 0, sizeof(m_vram));
    memset(m_oam, 0, sizeof(m_oam));
    memset(m_bios, 0, sizeof(m_bios));
    for (int i = 0; i < 4; i++) { m_timers[i].Reset(); m_dma[i].Reset(); }
    m_irq.Reset();
    m_romOffset = GBA_ROM_BASE;
    m_entryPoint = GBA_ROM_BASE;
    InitOpenBios();
}

GbaEmulator::~GbaEmulator() {}

void GbaEmulator::InitOpenBios()
{
    // 最小化 BIOS 存根：
    // 0x00000000: SWI 处理（返回）
    // 0x00000018: IRQ 向量
    // 使用 ARM 指令编码

    // 复位向量：跳转到 0x08000000
    // B 0x08000000 (相对跳转)
    // 实际上 GBA 从 ROM 入口点开始执行
    // BIOS 仅用于 SWI 调用

    // SWI 处理存根（0x00000008）：直接返回
    // MOVS PC, LR  (ARM: 0xE1B0F00E)
    uint32_t swiReturn = 0xE1B0F00E;
    memcpy(m_bios + 0x08, &swiReturn, 4);

    // IRQ 向量（0x00000018）：跳转到 IRQ 处理
    // LDR PC, [PC, #-4]  (ARM: 0xE51FF004)
    uint32_t irqJump = 0xE51FF004;
    memcpy(m_bios + 0x18, &irqJump, 4);

    // IRQ 处理地址（0x0000001C）：指向 BIOS IRQ 处理
    uint32_t irqHandler = 0x00000128;
    memcpy(m_bios + 0x1C, &irqHandler, 4);

    // 简单 IRQ 处理（0x00000128）：
    // 保存上下文 → 调用 IWRAM[0x03007FFC] 中游戏提供的用户 IRQ handler
    // → 清 IF → 恢复上下文 → SUBS PC,LR,#4 返回
    //
    // 内存布局（偏移相对 BIOS 起始 0x00000000）：
    //   0x128 +0:  STMFD SP!, {R0-R3,R12,LR}
    //   0x12C +4:  LDR R1, [PC, #0x24]         → 字面量 0x03007FFC @[0x158]
    //   0x130 +8:  LDR R0, [R1]                ; 读游戏 IRQ handler 指针
    //   0x134 +12: CMP R0, #0
    //   0x138 +16: BEQ skip(0x148)             ; 无 handler 则跳到清 IF
    //   0x13C +20: MOV LR, PC                  ; LR = 0x144（BX 后的返回地址）
    //   0x140 +24: BX  R0                      ; 调用用户 handler（支持 ARM/Thumb）
    //   0x144 +28: (skip) LDR R0, [PC, #0x10]  → 字面量 0x04000202 @[0x15C]
    //   0x148 +32: LDRH R1, [R0]               ; 读 IF
    //   0x14C +36: STRH R1, [R0]               ; 写回清 IF
    //   0x150 +40: LDMFD SP!, {R0-R3,R12,LR}
    //   0x154 +44: SUBS PC, LR, #4             ; RTI
    //   0x158 +48: 0x03007FFC                  ; 字面量：用户handler指针地址
    //   0x15C +52: 0x04000202                  ; 字面量：IF 寄存器地址
    static const uint32_t irqCode[] = {
        0xE92D500F,  // 0x128: STMFD SP!, {R0-R3,R12,LR}
        0xE59F1024,  // 0x12C: LDR R1, [PC, #0x24]  ; PC流水线=0x134, 目标=0x158
        0xE5910000,  // 0x130: LDR R0, [R1]           ; 读游戏 IRQ handler 地址
        0xE3500000,  // 0x134: CMP R0, #0
        0x0A000002,  // 0x138: BEQ +2*4 → 0x148（skip）
        0xE1A0E00F,  // 0x13C: MOV LR, PC             ; LR=0x144，BX 后返回此处
        0xE12FFF10,  // 0x140: BX R0                  ; 调用游戏 IRQ handler
        0xE59F0010,  // 0x144: LDR R0, [PC, #0x10]   ; PC流水线=0x14C, 目标=0x15C
        0xE1D010B0,  // 0x148: LDRH R1, [R0]          ; 读 IF（0x04000202）
        0xE1C010B0,  // 0x14C: STRH R1, [R0]          ; 写回清 IF
        0xE8BD500F,  // 0x150: LDMFD SP!, {R0-R3,R12,LR}
        0xE25EF004,  // 0x154: SUBS PC, LR, #4        ; RTI：返回被打断指令下一条
        0x03007FFC,  // 0x158: 字面量：游戏 IRQ handler 指针地址（IWRAM）
        0x04000202,  // 0x15C: 字面量：IF 寄存器地址
    };
    memcpy(m_bios + 0x128, irqCode, sizeof(irqCode));
}

bool GbaEmulator::LoadRom(const uint8_t* romData, size_t romSize, uint32_t romOffset, uint32_t entryPoint)
{
    if (!romData || romSize == 0)
        return false;

    m_romOffset = romOffset;
    m_entryPoint = entryPoint;

    // GBA ROM 最大 32MB
    size_t maxSize = GBA_ROM_SIZE;
    size_t copySize = (romSize < maxSize) ? romSize : maxSize;

    m_rom.assign(romData, romData + copySize);
    // 填充到 32MB（某些游戏依赖 ROM 镜像）
    while (m_rom.size() < maxSize)
    {
        size_t remaining = maxSize - m_rom.size();
        size_t chunk = (copySize < remaining) ? copySize : remaining;
        m_rom.insert(m_rom.end(), romData, romData + chunk);
    }

    // 调试：打印 ROM 加载信息（用于诊断数据表读取问题）
    LogDebug(L"[LoadRom] romSize=0x%X(%u) romOffset=0x%08X entryPoint=0x%08X",
             (unsigned)romSize, (unsigned)romSize, romOffset, entryPoint);

    // 转储原始 ROM 到文件，便于离线分析驱动代码位置
    {
        std::ofstream dump("C:\\Temp\\rom_dump.bin",
                           std::ios::binary | std::ios::out);
        if (dump.is_open())
        {
            dump.write(reinterpret_cast<const char*>(romData), romSize);
            dump.close();
            // LogDebug(L"[LoadRom] ROM 已转储到 /workspace/app-ctylrkc2iigx/tasks/rom_dump.bin (大小 %u)", (unsigned)romSize);
        }
        else
        {
            // LogDebug(L"[LoadRom] ROM 转储失败");
        }
    }
    // 关键偏移检查（已验证正常，日志关闭）
    if (romSize >= 0x730)
    {
        uint32_t v72C = (uint32_t)romData[0x72C] | ((uint32_t)romData[0x72D] << 8) |
                        ((uint32_t)romData[0x72E] << 16) | ((uint32_t)romData[0x72F] << 24);
        // LogDebug(L"[LoadRom] ROM[0x0800072C]=0x%08X (第三层循环基址, 0=无数据区)", v72C);
        (void)v72C;
    }
    else
    {
        // LogDebug(L"[LoadRom] romSize(0x%X) < 0x730，ROM[0x0800072C] 超出原始数据范围", (unsigned)romSize);
    }

    return true;
}

void GbaEmulator::Init(int outputSampleRate)
{
    m_outputSampleRate = outputSampleRate;
    m_apu.Init(outputSampleRate);
    Reset();
}

void GbaEmulator::Reset()
{
    memset(m_ewram, 0, sizeof(m_ewram));
    memset(m_iwram, 0, sizeof(m_iwram));
    memset(m_ioram, 0, sizeof(m_ioram));

    for (int i = 0; i < 4; i++) { m_timers[i].Reset(); m_dma[i].Reset(); }
    m_irq.Reset();
    // -------------------------------------------------------
    // GBA BIOS 初始化完成后 IME 状态为 1（中断已开启）。
    // 我们没有真正的 BIOS 执行，所以必须手动设置 IME=1，
    // 否则游戏写了 IE 但 IRQ handler 永远无法被调用（VBlank/Timer
    // 都不会触发中断向量），导致 Sappy 初始化死锁。
    // -------------------------------------------------------
    m_irq.ime = true;
    m_apu.Reset();
    m_halted = false;
    m_cycleAccum = 0;
    m_lastVcount = 0xFF;

    // 初始化 CPU 寄存器（模拟 BIOS 初始化后状态）
    memset(&m_regs, 0, sizeof(m_regs));
    m_regs.cpsr = 0x1F;         // System 模式
    m_regs.SP() = 0x03007F00;   // System 模式 SP（IWRAM 栈顶）
    m_regs.r[13] = 0x03007F00;  // 同上

    // -------------------------------------------------------
    // [v6 修复] 初始化各 CPU 模式的 banked SP（模拟 GBA BIOS 启动后状态）
    //
    // GBA BIOS 在启动时会依次切换到各特权模式，为每种模式的 SP 赋值：
    //   IRQ  模式（0x12）：SP_irq = 0x03007FA0
    //   SVC  模式（0x13）：SP_svc = 0x03007FE0
    //   System 模式      ：SP     = 0x03007F00
    //
    // 我们没有执行真正的 BIOS，memset 后所有 banked 寄存器为 0。
    // 若不手动赋值，SwitchMode(0x12) 时 r[13] = r13_irq = 0，
    // BIOS IRQ stub（0x128）执行 STMFD SP!, {R0-R3,R12,LR} 时：
    //   SP = 0 - 24 = 0xFFFFFFE8（超出所有 GBA 内存范围）
    // 寄存器数据被写到未映射区域（全部丢失），LDMFD 恢复出全零，
    // 最终 SUBS PC, LR, #4 → PC = 0 - 4 = 0xFFFFFFFC，程序跑飞。
    //
    // 根据日志行6980：[CPU:RUNAWAY] PC=0xFFFFFFFC SP=FFFFFFE8
    // -------------------------------------------------------
    m_regs.r13_irq = 0x03007FA0; // GBA BIOS 标准 IRQ 栈顶

    // 从 ROM 入口点开始执行
    if (!m_rom.empty())
    {
        uint32_t entry = m_entryPoint;
        // 如果是 Thumb 模式入口点（奇数地址），则设置 T 标志并清除最低位
        if (entry & 1)
        {
            m_regs.SetT(true);
            entry &= ~1u;
            // ARM7TDMI Thumb 流水线：PC 超前 4 字节（取指+译码各一条）
            // ExecuteThumb() 执行时会做 pc = m_regs.PC() - 4
            // 因此初始 m_regs.PC() 必须是 entry + 4，使第一条取指地址 = entry
            m_regs.PC() = entry + 4;
        }
        else
        {
            m_regs.SetT(false);
            // ARM7TDMI ARM 流水线：PC 超前 8 字节（取指+译码各一条）
            // ExecuteArm() 执行时会做 pc = m_regs.PC() - 8
            // 因此初始 m_regs.PC() 必须是 entry + 8，使第一条取指地址 = entry
            m_regs.PC() = entry + 8;
        }
        // Reset/APU日志已验证正常，v16 关闭
        // LogDebug(L"GbaEmulator::Reset: PC set to 0x%08X (T=%d)", ...);
    }

    // 初始化 IO 寄存器默认值
    // SOUNDCNT_X: APU 使能
    m_ioram[REG_SOUNDCNT_X] = 0x80;
    m_apu.WriteIO(GBA_IO_BASE + REG_SOUNDCNT_X, 0x80);

    // SOUNDBIAS: 默认偏置
    m_ioram[REG_SOUNDBIAS + 1] = 0x02;

    // 主音量最大
    m_ioram[REG_SOUNDCNT_L] = 0x77;
    m_apu.WriteIO(GBA_IO_BASE + REG_SOUNDCNT_L, 0x77);
    
    WriteIO(GBA_IO_BASE + 0x84, 0x80);
    WriteIO(GBA_IO_BASE + 0x80, 0x77); 
    WriteIO(GBA_IO_BASE + 0x81, 0xFF);
    WriteIO(GBA_IO_BASE + 0x82, 0x0B);
    WriteIO(GBA_IO_BASE + 0x83, 0x0B);
    WriteIO(GBA_IO_BASE + 0x88, 0x00);
    WriteIO(GBA_IO_BASE + 0x89, 0x02); 
    // APU Hard-Reset 已验证正常，v16 关闭
    // LogDebug(L"APU Hard-Reset and Force-Enabled");

    // [v21] repeat/切歌修复：Reset 时清除所有注入状态，
    // 确保下一轮 SoundDriverInit 能重新触发注入（否则 s_m4aInjected 永久锁导致噪音）。
    s_m4aInjected = false;
    s_m4aPending  = false;
    s_injecting   = false;
    s_injectSteps = 0;
    s_savedPC     = 0;
    s_savedLR     = 0;
    s_savedR0     = 0;
    s_savedR2     = 0;
    s_savedCPSR   = 0;
    s_savedSPSR   = 0;
    s_savedHalted = false;
    s_step10R2    = 0;
}

uint8_t GbaEmulator::ReadByte(uint32_t addr)
{
    uint32_t region = addr >> 24;
    switch (region)
    {
    case 0x00: // BIOS
        if (addr < 0x4000) return m_bios[addr & 0x3FFF];
        return 0;
    case 0x02: // EWRAM
        return m_ewram[addr & (GBA_EWRAM_SIZE - 1)];
    case 0x03: // IWRAM
        return m_iwram[addr & (GBA_IWRAM_SIZE - 1)];
    case 0x04: // IO
        return ReadIO(addr);
    case 0x05: // Palette
        return m_palette[addr & 0x3FF];
    case 0x06: // VRAM
        return m_vram[addr & 0x17FFF];
    case 0x07: // OAM
        return m_oam[addr & 0x3FF];
    case 0x08: case 0x09: // ROM 0
    case 0x0A: case 0x0B: // ROM 1
    case 0x0C: case 0x0D: // ROM 2
        if (!m_rom.empty())
        {
            // GSF 规范：地址应减去 romOffset 而非固定的 GBA_ROM_BASE
            // 因为 LoadRom 时的 romOffset 可能是 0x08000000 以外的值
            uint32_t offset = addr - m_romOffset;
            if (offset < m_rom.size())
                return m_rom[offset];
            // 如果超出范围，尝试镜像（某些 GSF 依赖此特性）
            return m_rom[offset % m_rom.size()];
        }
        return 0;
    default:
        // GBA 地址总线为 28 位，高 4 位被忽略（硬件行为）
        // 例如 0x85000100 → 0x05000100（Palette RAM）
        {
            uint32_t masked = addr & 0x0FFFFFFFu;
            if ((masked >> 24) != region)
                return ReadByte(masked);
        }
        return 0;
    }
}

uint16_t GbaEmulator::ReadHalf(uint32_t addr)
{
    addr &= ~1u;
    return (uint16_t)ReadByte(addr) | ((uint16_t)ReadByte(addr + 1) << 8);
}

uint32_t GbaEmulator::ReadWord(uint32_t addr)
{

    uint32_t alignedAddr = addr & ~3u;
    uint32_t val;
    // 快速路径：直接从 ROM 读取（最常见的访问）    
    if ((addr >> 24) >= 0x08 && (addr >> 24) <= 0x0D && !m_rom.empty())
    {
        uint32_t offset = alignedAddr - m_romOffset;
        if (offset + 3 < m_rom.size())
        {
            memcpy(&val, m_rom.data() + offset, 4);
        } else {
            val = 0;
        }
    } else {
        // 普通内存读取
        val = (uint32_t)ReadByte(alignedAddr) | 
              ((uint32_t)ReadByte(alignedAddr + 1) << 8) |
              ((uint32_t)ReadByte(alignedAddr + 2) << 16) | 
              ((uint32_t)ReadByte(alignedAddr + 3) << 24);
    }

    uint32_t shift = (addr & 3) * 8;
    if (shift != 0) {
        val = (val >> shift) | (val << (32 - shift));
    }
    return val;
}

void GbaEmulator::WriteByte(uint32_t addr, uint8_t value)
{
    uint32_t region = addr >> 24;
    switch (region)
    {
    case 0x02: m_ewram[addr & (GBA_EWRAM_SIZE - 1)] = value; break;
    case 0x03:
    {
        uint32_t iwramAddr = addr & (GBA_IWRAM_SIZE - 1);
        // [v14 修复C] IWRAM-Write 日志已完成诊断，v16 全部关闭
        // if ((iwramAddr >= 0x7E00u && iwramAddr <= 0x7FFFu) || iwramAddr < 0x1000u)
        // {
        //     LogDebug(L"[IWRAM-Write] addr=0x%08X old=0x%02X new=0x%02X PC=0x%08X",
        //              addr, m_iwram[iwramAddr], value, m_regs.PC());
        // }
        m_iwram[iwramAddr] = value;
        break;
    }
    case 0x04: WriteIO(addr, value); break;
    case 0x05: m_palette[addr & 0x3FF] = value; break;
    case 0x06: m_vram[addr & 0x17FFF] = value; break;
    case 0x07: m_oam[addr & 0x3FF] = value; break;
    default:
        // GBA 地址总线为 28 位，高 4 位被忽略（硬件行为）
        // 例如 0x85000100 → 0x05000100（Palette RAM）
        {
            uint32_t masked = addr & 0x0FFFFFFFu;
            if ((masked >> 24) != region)
                WriteByte(masked, value);
        }
        break;
    }
}

void GbaEmulator::WriteHalf(uint32_t addr, uint16_t value)
{
    addr &= ~1u;
    WriteByte(addr,     (uint8_t)(value & 0xFF));
    WriteByte(addr + 1, (uint8_t)(value >> 8));
}

void GbaEmulator::WriteWord(uint32_t addr, uint32_t value)
{
    addr &= ~3u;

    // v21 注入触发：只在首次（s_m4aInjected=false）且未在注入中时触发，
    // 注入完成后永久锁定（s_m4aInjected=true），避免重复注入导致音频卡顿。
    if (value == 0x68736D53u && (addr >> 24) == 0x02 && !s_m4aInjected && !s_injecting && !s_m4aPending) {
        LogDebug(L"[v21] 检测到 SoundDriverInit 完成 magic 写入 EWRAM addr=0x%08X → 准备异步注入 m4aOpenSong", addr);
        m_magicAddr    = addr;
        m_magicCleared = true;
        s_m4aPending   = true;
    }

    WriteByte(addr,     (uint8_t)(value & 0xFF));
    WriteByte(addr + 1, (uint8_t)((value >> 8) & 0xFF));
    WriteByte(addr + 2, (uint8_t)((value >> 16) & 0xFF));
    WriteByte(addr + 3, (uint8_t)((value >> 24) & 0xFF));
}

uint8_t GbaEmulator::ReadIO(uint32_t addr)
{
    uint32_t reg = addr & 0x3FF;

    // ---------------------------------------------------------------
    // [v7 修复 Bug-A] Timer 计数寄存器必须返回实时 counter 值
    //
    // GBA 硬件：Timer 是独立运行的 16-bit 上行计数器，CPU 可随时读取
    // 当前计数值（TM0CNT_L = 0x04000100 等）。
    //
    // 原实现缺陷：
    //   - WriteIO 写 reload（0x100/0x101）时，将 reload 字节存入 m_ioram[reg]
    //   - TickTimers 更新 m_timers[i].counter，但从不回写 m_ioram
    //   - 因此 ReadIO 返回的是"最后一次写入的 reload 快照"，而非实时计数值
    //
    // 后果（日志证据）：
    //   Sappy SoundDriverMain 在 ROM 0x08A9BCAC 处执行轮询循环：
    //     loop: LDR R0,[R1=0x04000102]  → AND R0,R2  → CMP R0,R3  → BNE loop
    //   每次读到的 R0 始终为 0x00040000（m_ioram 快照），条件永不满足 →
    //   Sappy 死循环，无法进行 PCM 混音，FIFO 永远不被填充，输出全零。
    //
    // 修复：对 TM0CNT_L 低/高字节（offset 0/1）实时返回 m_timers[i].counter；
    //       TM0CNT_H（offset 2/3，控制字节）仍读 m_ioram（由 WriteIO 维护）。
    // ---------------------------------------------------------------
    if (reg >= 0x100 && reg <= 0x10F)
    {
        int timerIdx  = (reg - 0x100) >> 2;   // 0..3（4 个 Timer）
        int timerByte = (reg - 0x100) & 3;     // 0=CNT_L低, 1=CNT_L高, 2=CNT_H低, 3=CNT_H高

        if (timerIdx < 4)
        {
            if (timerByte == 0)
                return (uint8_t)(m_timers[timerIdx].counter & 0xFF);
            if (timerByte == 1)
                return (uint8_t)((m_timers[timerIdx].counter >> 8) & 0xFF);
            // timerByte == 2/3：控制寄存器，读 m_ioram（WriteIO 已正确写入）
        }
    }

    // ---------------------------------------------------------------
    // [v9 修复 Bug-A] IE/IF/IME 必须返回实时寄存器值，不能读 m_ioram
    //
    // 问题根因：
    //   m_irq.ifl 由内部代码直接设置（m_irq.ifl |= bit），从不经过 WriteIO，
    //   所以 m_ioram[0x202] 始终是 0（初始值），或者是 BIOS 上次写入的 0x00。
    //
    //   BIOS IRQ stub（0x00000148）执行 `LDRH R1,[REG_IF=0x04000202]`：
    //     ReadIO(0x202) → m_ioram[0x202] = 0x00 → R1 = 0
    //   然后 0x00000154：`STRH R1=0,[REG_IF]`：
    //     WriteIO(0x202, 0x00) → ifl &= ~0x00 → ifl 不变！
    //
    //   结果：VBlank ifl bit0 永远无法被清除 → exception return 后 CPU 检测到
    //   ifl & ie != 0（IME=1, CPSR.I 已恢复为0）→ HandleInterrupt 再次触发 →
    //   PC = 0x00000018（IRQ向量）→ 无限重入，Sappy PCM mixer 永远不能运行
    //   → FIFO DMA 读出全零 → 完全无声
    //
    //   日志证据（v8fix 日志）：
    //     [WriteIO] reg=0x202 val=0x00（BIOS写，但读回的是0，清不掉中断）
    //     [IWRAMEntry+084] PC=0x00000018（exception return后立刻重入IRQ向量）
    //     [IRQ] Enter: pending=0x0001（VBlank ifl 从未清零）
    //
    // 修复：对 IE/IF/IME 直接返回实时成员变量，绕过 m_ioram
    // ---------------------------------------------------------------
    if (reg == 0x200) return (uint8_t)(m_irq.ie & 0xFF);
    if (reg == 0x201) return (uint8_t)((m_irq.ie >> 8) & 0xFF);
    if (reg == 0x202) return (uint8_t)(m_irq.ifl & 0xFF);        // ← 关键：返回实时 IF
    if (reg == 0x203) return (uint8_t)((m_irq.ifl >> 8) & 0xFF); // ← 关键：返回实时 IF 高字节
    if (reg == 0x208) return (uint8_t)(m_irq.ime ? 1 : 0);
    if (reg == 0x209) return 0;

    if (reg < sizeof(m_ioram))
        return m_ioram[reg];
    return 0;
}

void GbaEmulator::WriteIO(uint32_t addr, uint8_t value)
{
    uint32_t reg = addr & 0x3FF;
    if (reg < sizeof(m_ioram))
    {
        // REG_VCOUNT (0x04000006-0x04000007) 是硬件只读寄存器，忽略一切写入
        // GBA 规范：VCOUNT 由硬件扫描线逻辑驱动，CPU 写入无效
        // 若此处不保护，游戏 STRH/STR 初始化代码可能覆盖 VCOUNT，
        // 导致 LDRB 读回错误值，VCOUNT 等待循环永不退出
        if (reg == 0x006 || reg == 0x007)
        {
        // VCOUNT 只读保护（无需日志，v16 关闭）
        // LogDebug(L"  [WriteIO] VCOUNT 只读保护：reg=0x%03X val=0x%02X 已忽略", reg, value);
            return;
        }
        m_ioram[reg] = value;
    }

    // 调试：记录 IO 寄存器写入
    // 策略：
    //   前 10 帧 (m_frameCount < 10)：记录所有 APU/DMA/Timer/IRQ 写入，
    //   确保捕获 else 初始化分支（magic 拦截后第一帧触发）的完整寄存器序列
    {
        bool logThis = (reg >= 0x060 && reg <= 0x0DF) ||  // APU + DMA
                       (reg >= 0x100 && reg <= 0x10F) ||  // 定时器
                       reg == 0x200 || reg == 0x201 ||    // IE
                       reg == 0x202 || reg == 0x203 ||    // IF
                       reg == 0x208 || reg == 0x209 ||    // IME
                       (m_frameCount < 2);                // 前 2 帧记录全部

        if (logThis)
        {
            // WriteIO 日志已验证正常，v16 关闭
            // LogDebug(L"  [WriteIO] reg=0x%03X val=0x%02X  (frame=%d IE=%04X IME=%d magicCleared=%d PC=0x%08X)",
            //          reg, value, m_frameCount, (int)m_irq.ie, (int)m_irq.ime, (int)m_magicCleared, m_regs.PC());
        }
    }

    // 转发到 APU
    if (reg >= 0x060 && reg < 0x0B0)
    {
        m_apu.WriteIO(addr, value);
        // APU 已确认正常启用，v16 关闭日志
        if (reg == REG_SOUNDCNT_X && (value & 0x80)) {
            // LogDebug(L"GbaEmulator::WriteIO: APU Enabled via REG_SOUNDCNT_X");
        }
    }

    // DMA FIFO 直接写（CPU 直接写 FIFO 寄存器）
    // FIFO A: 0x040000A0-0x040000A3，FIFO B: 0x040000A4-0x040000A7
    // 游戏代码可能通过 STMIA 或逐字节写入，每个字节都需要推入 FIFO
    if (reg >= 0x0A0 && reg <= 0x0A3) m_apu.GetFifoA().Push((int8_t)value);
    if (reg >= 0x0A4 && reg <= 0x0A7) m_apu.GetFifoB().Push((int8_t)value);

    // ---------------------------------------------------------------
    // DMA 通道寄存器（0x0B0-0x0DF，4 通道 × 12 字节）
    // 格式：SAD(4) DAD(4) CNT_L(2) CNT_H(2)，每通道间隔 0x0C
    // ---------------------------------------------------------------
    if (reg >= 0x0B0 && reg < 0x0E0)
    {
        int ch  = (reg - 0x0B0) / 0x0C;
        int off = (reg - 0x0B0) % 0x0C;
        if (ch >= 0 && ch < 4)
        {
            switch (off)
            {
            // SAD（源地址）字节 0-3
            case 0: m_dma[ch].src = (m_dma[ch].src & 0xFFFFFF00u) | value; break;
            case 1: m_dma[ch].src = (m_dma[ch].src & 0xFFFF00FFu) | ((uint32_t)value << 8); break;
            case 2: m_dma[ch].src = (m_dma[ch].src & 0xFF00FFFFu) | ((uint32_t)value << 16); break;
            case 3: m_dma[ch].src = (m_dma[ch].src & 0x00FFFFFFu) | ((uint32_t)value << 24); break;
            // DAD（目标地址）字节 4-7
            case 4: m_dma[ch].dst = (m_dma[ch].dst & 0xFFFFFF00u) | value; break;
            case 5: m_dma[ch].dst = (m_dma[ch].dst & 0xFFFF00FFu) | ((uint32_t)value << 8); break;
            case 6: m_dma[ch].dst = (m_dma[ch].dst & 0xFF00FFFFu) | ((uint32_t)value << 16); break;
            case 7: m_dma[ch].dst = (m_dma[ch].dst & 0x00FFFFFFu) | ((uint32_t)value << 24); break;
            // CNT_L（传输字数）字节 8-9
            case 8:  m_dma[ch].count = (m_dma[ch].count & 0xFF00u) | value; break;
            case 9:  m_dma[ch].count = (m_dma[ch].count & 0x00FFu) | ((uint16_t)value << 8); break;
            // CNT_H（控制）字节 10
            case 10: m_dma[ch].control = (m_dma[ch].control & 0xFF00u) | value; break;
            // CNT_H 高字节（含使能位 bit15），写入时解析控制字段并决定是否激活
            case 11:
            {
                bool wasEnabled = m_dma[ch].enabled;
                m_dma[ch].control = (m_dma[ch].control & 0x00FFu) | ((uint16_t)value << 8);

                // 解析控制位
                m_dma[ch].dst_ctrl   = (m_dma[ch].control >> 5)  & 3;
                m_dma[ch].src_ctrl   = (m_dma[ch].control >> 7)  & 3;
                m_dma[ch].repeat     = (m_dma[ch].control >> 9)  & 1;
                m_dma[ch].word_size  = (m_dma[ch].control >> 10) & 1;
                m_dma[ch].timing     = (m_dma[ch].control >> 12) & 3;
                m_dma[ch].irq_enable = (m_dma[ch].control >> 14) & 1;
                m_dma[ch].enabled    = (m_dma[ch].control >> 15) & 1;

                // 0→1 跳变：锁存地址，必要时立即触发
                if (!wasEnabled && m_dma[ch].enabled)
                {
                    m_dma[ch].src_latch = m_dma[ch].src;
                    m_dma[ch].dst_latch = m_dma[ch].dst;

                    // DMA 启动节点已验证正常，v16 关闭
                    // LogDebug(L"[DMA] ch%d Enabled: src=0x%08X dst=0x%08X count=%d "
                    //          L"word=%d timing=%d repeat=%d dst_ctrl=%d src_ctrl=%d irq=%d PC=0x%08X",
                    //          ch, m_dma[ch].src_latch, m_dma[ch].dst_latch, (int)m_dma[ch].count,
                    //          (int)m_dma[ch].word_size, m_dma[ch].timing,
                    //          (int)m_dma[ch].repeat, m_dma[ch].dst_ctrl,
                    //          m_dma[ch].src_ctrl, (int)m_dma[ch].irq_enable, m_regs.PC());

                    if (m_dma[ch].timing == 0)      // 立即传输
                        RunDma(ch);
                }
                break;
            }
            }
        }
    }

    // 定时器控制
    if (reg >= 0x100 && reg < 0x110)
    {
        int timerIdx = (reg - 0x100) >> 2;
        int timerReg = (reg - 0x100) & 3;
        if (timerIdx < 4)
        {
            if (timerReg == 0) // 低字节重载值
            {
                m_timers[timerIdx].reload = (m_timers[timerIdx].reload & 0xFF00) | value;
                // [v7 修复 Bug-B] 若 Timer 当前已启用，写 reload 后立即同步 counter
                // GBA 硬件：写 TM0CNT_L/H（reload）不会重置 counter；counter 继续计数，
                // 下次溢出时才使用新 reload 重载。
                // 但 Sappy 的使用模式是：stop → write_reload → restart（写 ctrl=0x80）。
                // 当 Sappy 遗漏 restart 步骤时（ctrl 未被重置为 0x80），Timer 停止，
                // 无 overflow 触发 → FIFO DMA 不工作 → 样本全零。
                // 此处仅在已启用时将新 reload 立即同步到 counter（符合部分硬件修订版行为），
                // 以防 Sappy 写 reload 后直接依赖计数而不重启。
                if (m_timers[timerIdx].enabled)
                    m_timers[timerIdx].counter =
                        (m_timers[timerIdx].counter & 0xFF00) | value;
            }
            else if (timerReg == 1) // 高字节重载值
            {
                m_timers[timerIdx].reload = (m_timers[timerIdx].reload & 0x00FF) | ((uint16_t)value << 8);
                if (m_timers[timerIdx].enabled)
                    m_timers[timerIdx].counter =
                        (m_timers[timerIdx].counter & 0x00FF) | ((uint16_t)value << 8);
            }
            else if (timerReg == 2) // 控制寄存器低字节
            {
                static const int prescalers[4] = {1, 64, 256, 1024};
                bool wasEnabled = m_timers[timerIdx].enabled;
                m_timers[timerIdx].prescaler = prescalers[value & 3];
                m_timers[timerIdx].cascade   = (value >> 2) & 1;
                m_timers[timerIdx].irq_enable = (value >> 6) & 1;
                m_timers[timerIdx].enabled   = (value >> 7) & 1;
                if (!wasEnabled && m_timers[timerIdx].enabled)
                {
                    m_timers[timerIdx].counter = m_timers[timerIdx].reload;
                // Timer 启动已验证正常，v16 关闭
                // LogDebug(L"[Timer] Timer%d Started: reload=0x%04X prescaler=%d "
                //          L"cascade=%d irq=%d fifoA_timer=%d fifoB_timer=%d PC=0x%08X",
                //          timerIdx, ...);
                }
            }
        }
    }

    // 中断控制
    if (reg == 0x200) m_irq.ie = (m_irq.ie & 0xFF00) | value;
    if (reg == 0x201) m_irq.ie = (m_irq.ie & 0x00FF) | ((uint16_t)value << 8);
    if (reg == 0x202) m_irq.ifl &= ~value;  // 写1清除
    if (reg == 0x203) m_irq.ifl &= ~((uint16_t)value << 8);
    if (reg == 0x208) m_irq.ime = value & 1;

    // HALT 控制
    if (reg == 0x301 && (value & 0x80) == 0)
        m_halted = true;
}

void GbaEmulator::TickTimers(int cycles)
{
    for (int i = 0; i < 4; i++)
    {
        if (!m_timers[i].enabled || m_timers[i].cascade)
            continue;

        m_timers[i].prescaler_cnt += cycles;
        while (m_timers[i].prescaler_cnt >= m_timers[i].prescaler)
        {
            m_timers[i].prescaler_cnt -= m_timers[i].prescaler;
            uint16_t prev = m_timers[i].counter;
            m_timers[i].counter++;
            if (m_timers[i].counter == 0)
            {
                // Timer 溢出已验证正常，v16 关闭
                // LogDebug(L"[Timer] Timer%d Overflow: ...", i, ...);
                m_timers[i].counter = m_timers[i].reload;
                TimerOverflow(i);
            }
        }
    }
}

void GbaEmulator::TimerOverflow(int index)
{
    // TimerOverflow 日志已验证正常，v16 关闭
    // LogDebug(L"[Timer] Timer%d Overflow: reload=0x%04X, FIFO_A.timer=%d, FIFO_B.timer=%d", ...);

    // 通知 APU：只有与 FIFO 绑定的 Timer 溢出时才 Pop 样本
    m_apu.OnTimerOverflow(index);

    // 触发 Sound FIFO DMA（timing == 3 = 特殊/Sound FIFO）
    // -------------------------------------------------------
    // 关键修复：只触发 timer_select 与当前溢出 Timer 编号匹配的 DMA 通道。
    // 原实现 CheckDmaTiming(3) 会一次性触发所有 timing==3 的 DMA，
    // 导致 Timer0 溢出时 Timer1 绑定的 FIFO 也被填充（或反之），
    // 产生 FIFO 数据时序错乱，最终表现为无声或杂音。
    // -------------------------------------------------------
    for (int ch = 0; ch < 4; ch++)
    {
        if (!m_dma[ch].enabled || m_dma[ch].timing != 3) continue;

        bool isFifoA = (m_dma[ch].dst == 0x040000A0u || m_dma[ch].dst_latch == 0x040000A0u);
        bool isFifoB = (m_dma[ch].dst == 0x040000A4u || m_dma[ch].dst_latch == 0x040000A4u);

        // 只有目标 FIFO 的 timer_select 与当前溢出 Timer 编号相同时才触发
        bool shouldFire = false;
        if (isFifoA && (int)m_apu.GetFifoA().timer_select == index) shouldFire = true;
        if (isFifoB && (int)m_apu.GetFifoB().timer_select == index) shouldFire = true;

        if (shouldFire)
        {
            // DMA FIFO 触发已验证正常，v16 关闭
            // LogDebug(L"[DMA] Timer%d Overflow → Fire DMA ch%d ...", index, ch, ...);
            RunDma(ch);
        }
    }

    // 级联到下一个定时器
    if (index < 3 && m_timers[index + 1].enabled && m_timers[index + 1].cascade)
    {
        m_timers[index + 1].counter++;
        if (m_timers[index + 1].counter == 0)
        {
            m_timers[index + 1].counter = m_timers[index + 1].reload;
            TimerOverflow(index + 1);
        }
    }

    // 触发中断
    if (m_timers[index].irq_enable)
    {
        m_irq.ifl |= (1 << (3 + index));
        if (m_irq.ime && (m_irq.ie & m_irq.ifl))
            m_halted = false;
    }
}

bool GbaEmulator::CheckCondition(uint32_t cond)
{
    switch (cond)
    {
    case 0x0: return m_regs.Z();
    case 0x1: return !m_regs.Z();
    case 0x2: return m_regs.C();
    case 0x3: return !m_regs.C();
    case 0x4: return m_regs.N();
    case 0x5: return !m_regs.N();
    case 0x6: return m_regs.V();
    case 0x7: return !m_regs.V();
    case 0x8: return m_regs.C() && !m_regs.Z();
    case 0x9: return !m_regs.C() || m_regs.Z();
    case 0xA: return m_regs.N() == m_regs.V();
    case 0xB: return m_regs.N() != m_regs.V();
    case 0xC: return !m_regs.Z() && (m_regs.N() == m_regs.V());
    case 0xD: return m_regs.Z() || (m_regs.N() != m_regs.V());
    case 0xE: return true;
    default:  return false;
    }
}

uint32_t GbaEmulator::BarrelShift(uint32_t value, uint32_t shiftType,
                                   uint32_t shiftAmt, bool& carry)
{
    if (shiftAmt == 0) return value;
    switch (shiftType)
    {
    case 0: // LSL
        if (shiftAmt >= 32) { carry = (shiftAmt == 32) ? (value & 1) : false; return 0; }
        carry = (value >> (32 - shiftAmt)) & 1;
        return value << shiftAmt;
    case 1: // LSR
        if (shiftAmt >= 32) { carry = (shiftAmt == 32) ? ((value >> 31) & 1) : false; return 0; }
        carry = (value >> (shiftAmt - 1)) & 1;
        return value >> shiftAmt;
    case 2: // ASR
        if (shiftAmt >= 32) { carry = (value >> 31) & 1; return carry ? 0xFFFFFFFF : 0; }
        carry = (value >> (shiftAmt - 1)) & 1;
        return (uint32_t)((int32_t)value >> shiftAmt);
    case 3: // ROR
        shiftAmt &= 31;
        if (shiftAmt == 0) return value;
        carry = (value >> (shiftAmt - 1)) & 1;
        return (value >> shiftAmt) | (value << (32 - shiftAmt));
    }
    return value;
}

int GbaEmulator::ExecuteArm()
{
    uint32_t pc = m_regs.PC() - 8; // ARM 流水线：PC 超前 8 字节
    uint32_t instr = ReadWord(pc);
    m_regs.PC() += 4;

    // ARM 规范：指令执行期间，R15 作为源操作数读取时，值 = 执行地址+8（即 pc+8）。
    // 代码在 PC += 4 后，m_regs.r[15] = pc+12（多4字节），故用此 lambda 统一修正。
    // 写 r15（分支目标）仍直接操作 m_regs.PC()，不受此 lambda 影响。
    auto GetReg = [&](uint32_t idx) -> uint32_t {
        return (idx == 15u) ? (pc + 8u) : m_regs.r[idx];
    };

    // 检查条件码
    uint32_t cond = instr >> 28;
    if (!CheckCondition(cond))
        return 1;

    uint32_t type = (instr >> 25) & 7;

    // 分支指令 B / BL
    // ARM 规范：目标地址 = PC_pipeline + SignExtend(imm24)*4
    //   其中 PC_pipeline = 当前执行地址（pc）+ 8
    // 执行到这里时，m_regs.PC() 已经 += 4，因此 m_regs.PC() = pc + 12。
    // 下次 ExecuteArm 取指：new_pc = m_regs.PC() - 8。
    // 要使 new_pc = target，需要 m_regs.PC() = target + 8。
    if ((instr & 0x0E000000) == 0x0A000000)
    {
        int32_t offset = (int32_t)(instr << 8) >> 6; // 符号扩展并 <<2
        uint32_t target = (pc + 8) + (uint32_t)offset; // ARM PC_pipeline + offset
        if (instr & (1 << 24)) // BL：LR = 当前指令的下一条地址
            m_regs.LR() = pc + 4;
        m_regs.PC() = target + 8; // 补偿流水线：下次 -8 后 = target
        return 3;
    }

    // BX / BLX 指令（跳转到寄存器，可切换 ARM/Thumb 模式）
    if ((instr & 0x0FFFFFF0) == 0x012FFF10 ||
        (instr & 0x0FFFFFF0) == 0x012FFF30) // BLX
    {
        uint32_t rn = instr & 0xF;
        uint32_t addr = m_regs.r[rn];
        bool isBLX = ((instr & 0x0FFFFFF0) == 0x012FFF30);
        if (isBLX)
            m_regs.LR() = pc + 4;
        uint32_t target = addr & ~1u;
        if (addr & 1)
        {
            // 切换到 Thumb 模式：下次 ExecuteThumb 取指做 pc_t = PC - 4
            m_regs.SetT(true);
            m_regs.PC() = target + 4;
        }
        else
        {
            // 保持 ARM 模式：下次 ExecuteArm 取指做 pc_a = PC - 8
            m_regs.SetT(false);
            m_regs.PC() = target + 8;
        }

        // -------------------------------------------------------
        // [v10A 修复] ARM BX/BLX 目标为未初始化 IWRAM（全零）时注入空函数返回
        // BLX 情况下 LR 已被本指令覆盖（存的是当前 PC+4），直接使用。
        // [v14 修复B] 额外打印 IWRAM 首 8 字节内容供诊断。
        // -------------------------------------------------------
        if ((target >> 24) == 0x03u)
        {
            if (ReadHalf(target)       == 0x0000u &&
                ReadHalf(target + 2u)  == 0x0000u &&
                ReadHalf(target + 4u)  == 0x0000u)
            {
                uint32_t lr = m_regs.LR();
                LogDebug(L"[CPU:BX-NULL-IWRAM] ARM BX→0x%08X 目标 IWRAM 全零（未初始化）"
                         L" IWRAM[+0..+7]=0x%08X 0x%08X 注入空函数返回 LR=0x%08X T=%d",
                         target, ReadWord(target), ReadWord(target + 4u),
                         lr, (int)((lr & 1u) != 0u));
                uint32_t retTarget = lr & ~1u;
                if (lr & 1u) { m_regs.SetT(true);  m_regs.PC() = retTarget + 4u; }
                else         { m_regs.SetT(false); m_regs.PC() = retTarget + 8u; }
            }
        }
        return 3;
    }

    // ------------------------------------------------------------------
    // 关键修复：Multiply / Multiply-Long / SWP / Halfword传输 / MRS/MSR
    // 这些指令的高位编码 bits[27:26] 也是 00，与"数据处理指令"完全相同，
    // 如果不在数据处理指令之前优先识别它们，会被错误地当成 AND/EOR/... 等
    // ALU 操作执行，导致寄存器被写入完全错误的值。
    // GBA 声音引擎（如 Sappy/MP2K "m4a" 引擎，绝大多数商业 GBA 游戏使用）
    // 的 ARM 模式代码大量使用 MUL（音量/包络/采样率换算）和 LDRH/STRH
    // （读写 16 位定时器/采样表/IO 寄存器），一旦被误解码，会导致混音
    // 例程算出的地址或数值错乱，表现为完全无声或播放崩溃跑飞。
    // ------------------------------------------------------------------

    // Multiply / Multiply-Accumulate (MUL/MLA)
    // cond 000000 A S Rd Rn Rs 1001 Rm
    if ((instr & 0x0FC000F0) == 0x00000090)
    {
        bool A = (instr >> 21) & 1;
        bool S = (instr >> 20) & 1;
        uint32_t rd = (instr >> 16) & 0xF; // 目标寄存器
        uint32_t rn = (instr >> 12) & 0xF; // 累加值（MLA）
        uint32_t rs = (instr >> 8)  & 0xF;
        uint32_t rm = instr & 0xF;

        uint32_t result = m_regs.r[rm] * m_regs.r[rs];
        if (A) result += m_regs.r[rn];
        m_regs.r[rd] = result;

        if (S)
        {
            m_regs.SetN(result >> 31);
            m_regs.SetZ(result == 0);
        }
        return 2;
    }

    // Multiply Long (UMULL/UMLAL/SMULL/SMLAL)
    // cond 00001 U A S RdHi RdLo Rs 1001 Rm
    if ((instr & 0x0F8000F0) == 0x00800090)
    {
        bool signedMul = (instr >> 22) & 1; // U: 0=无符号，1=有符号
        bool A          = (instr >> 21) & 1;
        bool S          = (instr >> 20) & 1;
        uint32_t rdHi = (instr >> 16) & 0xF;
        uint32_t rdLo = (instr >> 12) & 0xF;
        uint32_t rs   = (instr >> 8)  & 0xF;
        uint32_t rm   = instr & 0xF;

        uint64_t result;
        if (signedMul)
        {
            int64_t a = (int64_t)(int32_t)m_regs.r[rm];
            int64_t b = (int64_t)(int32_t)m_regs.r[rs];
            result = (uint64_t)(a * b);
        }
        else
        {
            result = (uint64_t)m_regs.r[rm] * (uint64_t)m_regs.r[rs];
        }

        if (A)
        {
            uint64_t acc = ((uint64_t)m_regs.r[rdHi] << 32) | (uint64_t)m_regs.r[rdLo];
            result += acc;
        }

        m_regs.r[rdLo] = (uint32_t)(result & 0xFFFFFFFFu);
        m_regs.r[rdHi] = (uint32_t)(result >> 32);

        if (S)
        {
            m_regs.SetN((result >> 63) & 1);
            m_regs.SetZ(result == 0);
        }
        return 3;
    }

    // Single Data Swap (SWP/SWPB)
    // cond 00010 B 00 Rn Rd 00001001 Rm
    if ((instr & 0x0FB00FF0) == 0x01000090)
    {
        bool byteSwap = (instr >> 22) & 1;
        uint32_t rn = (instr >> 16) & 0xF;
        uint32_t rd = (instr >> 12) & 0xF;
        uint32_t rm = instr & 0xF;
        uint32_t addr = m_regs.r[rn];

        if (byteSwap)
        {
            uint8_t oldVal = ReadByte(addr);
            WriteByte(addr, (uint8_t)m_regs.r[rm]);
            m_regs.r[rd] = oldVal;
        }
        else
        {
            uint32_t oldVal = ReadWord(addr);
            WriteWord(addr, m_regs.r[rm]);
            m_regs.r[rd] = oldVal;
        }
        return 4;
    }

    // MRS：读取 CPSR/SPSR 到寄存器
    // cond 00010 R 001111 Rd 000000000000
    if ((instr & 0x0FBF0FFF) == 0x010F0000)
    {
        bool R = (instr >> 22) & 1;
        uint32_t rd = (instr >> 12) & 0xF;
        m_regs.r[rd] = R ? m_regs.spsr : m_regs.cpsr;
        return 1;
    }

    // MSR：将寄存器或立即数写入 CPSR/SPSR（支持按字段掩码 c/x/s/f 部分写入）
    // cond 00 I 10 R 10 field Rd/SBZ 立即数或 Rm
    if ((instr & 0x0DB00000) == 0x01200000)
    {
        bool imm  = (instr >> 25) & 1;
        bool R    = (instr >> 22) & 1;
        uint32_t fieldMask = (instr >> 16) & 0xF;

        uint32_t val;
        if (imm)
        {
            uint32_t rot = ((instr >> 8) & 0xF) * 2;
            uint32_t imm8 = instr & 0xFF;
            val = rot ? ((imm8 >> rot) | (imm8 << (32 - rot))) : imm8;
        }
        else
        {
            val = m_regs.r[instr & 0xF];
        }

        uint32_t mask = 0;
        if (fieldMask & 1) mask |= 0x000000FFu; // control 字段 (c)
        if (fieldMask & 2) mask |= 0x0000FF00u; // 扩展字段 (x)
        if (fieldMask & 4) mask |= 0x00FF0000u; // 状态字段 (s)
        if (fieldMask & 8) mask |= 0xFF000000u; // 标志字段 (f)

        if (R) m_regs.spsr = (m_regs.spsr & ~mask) | (val & mask);
        else   m_regs.cpsr = (m_regs.cpsr & ~mask) | (val & mask);
        return 1;
    }

    // Halfword / 有符号数据传输：LDRH / STRH / LDRSB / LDRSH（寄存器或立即数偏移）
    // cond 000 P U I W L Rn Rd offsetHi 1 SH 1 offsetLo/Rm
    // SH: 01=无符号半字, 10=有符号字节, 11=有符号半字（00 已被上面的乘法/SWP占用）
    if ((instr & 0x0E000090) == 0x00000090 && (((instr >> 5) & 3) != 0))
    {
        bool pre    = (instr >> 24) & 1;
        bool up     = (instr >> 23) & 1;
        bool immOff = (instr >> 22) & 1; // I：1=立即数偏移，0=寄存器偏移
        bool wb     = (instr >> 21) & 1;
        bool load   = (instr >> 20) & 1;
        uint32_t rn = (instr >> 16) & 0xF;
        uint32_t rd = (instr >> 12) & 0xF;
        uint32_t sh = (instr >> 5)  & 3;

        uint32_t offset = immOff
            ? (((instr >> 4) & 0xF0) | (instr & 0xF))
            : m_regs.r[instr & 0xF];

        uint32_t base = GetReg(rn);
        if (rn == 15) base &= ~1u;
        uint32_t addr = base;
        if (pre) addr = up ? addr + offset : addr - offset;

        if (load)
        {
            uint32_t val;
            uint16_t raw = ReadHalf(addr);
            switch (sh)
            {
            case 1:  val = (uint32_t)raw; break;                               // LDRH
            case 2:  val = (uint32_t)(int32_t)(int8_t)ReadByte(addr); break;              // LDRSB
            case 3:  val = (uint32_t)(int32_t)(int16_t)raw; break;// LDRSH
            default: val = 0; break;
            }
            m_regs.r[rd] = val;
        }
        else
        {
            // 存储形式仅 STRH（sh==1）有意义
            WriteHalf(addr, (uint16_t)m_regs.r[rd]);
        }

        if (!pre) addr = up ? base + offset : base - offset;
        if (wb || !pre) m_regs.r[rn] = addr;

        return load ? 3 : 2;
    }

    // 数据处理指令
    if ((instr & 0x0C000000) == 0x00000000)
    {
        uint32_t opcode = (instr >> 21) & 0xF;
        uint32_t s      = (instr >> 20) & 1;
        uint32_t rn     = (instr >> 16) & 0xF;
        uint32_t rd     = (instr >> 12) & 0xF;
        bool     imm    = (instr >> 25) & 1;

        uint32_t op2;
        bool carry = m_regs.C();
        if (imm)
        {
            uint32_t rot = ((instr >> 8) & 0xF) * 2;
            op2 = instr & 0xFF;
            if (rot) op2 = (op2 >> rot) | (op2 << (32 - rot));
        }
        else
        {
            uint32_t rm = instr & 0xF;
            uint32_t shiftType = (instr >> 5) & 3;
            uint32_t shiftAmt;
            if (instr & (1 << 4))
                shiftAmt = m_regs.r[(instr >> 8) & 0xF] & 0xFF;
            else
                shiftAmt = (instr >> 7) & 0x1F;
            op2 = BarrelShift(GetReg(rm), shiftType, shiftAmt, carry);
        }

        uint32_t rnVal = GetReg(rn);
        uint32_t result = 0;
        bool writeResult = true;
        bool aluCarry = m_regs.C();
        bool aluOverflow = m_regs.V();
        uint64_t res64 = 0;

        switch (opcode)
        {
        case 0x0: result = rnVal & op2; break;  // AND
        case 0x1: result = rnVal ^ op2; break;  // EOR
        case 0x2: result = rnVal - op2; aluCarry = (rnVal >= op2);aluOverflow = ((rnVal ^ op2) & (rnVal ^ result)) >> 31;break;  // SUB
        case 0x3: result = op2 - rnVal; aluCarry = (op2 >= rnVal);aluOverflow = ((op2 ^ rnVal) & (op2 ^ result)) >> 31;break;  // RSB
        case 0x4: res64 = (uint64_t)rnVal + op2; result = (uint32_t)res64; aluCarry = (res64 > 0xFFFFFFFFu);aluOverflow = (~(rnVal ^ op2) & (rnVal ^ result)) >> 31;break;  // ADD
        case 0x5: result = rnVal + op2 + (uint32_t)m_regs.C(); break; // ADC
        case 0x6: result = rnVal - op2 - 1 + (uint32_t)m_regs.C(); break; // SBC
        case 0x7: result = op2 - rnVal - 1 + (uint32_t)m_regs.C(); break; // RSC
        case 0x8: result = rnVal & op2; writeResult = false; break; // TST
        case 0x9: result = rnVal ^ op2; writeResult = false; break; // TEQ
        case 0xA: result = rnVal - op2; aluCarry = (rnVal >= op2);aluOverflow = ((rnVal ^ op2) & (rnVal ^ result)) >> 31;writeResult = false; break; // CMP
        case 0xB: res64 = (uint64_t)rnVal + op2;result = (uint32_t)res64; aluCarry = (res64 > 0xFFFFFFFFu);aluOverflow = (~(rnVal ^ op2) & (rnVal ^ result)) >> 31;writeResult = false; break; // CMN
        case 0xC: result = rnVal | op2; break;  // ORR
        case 0xD: result = op2; break;           // MOV
        case 0xE: result = rnVal & ~op2; break;  // BIC
        case 0xF: result = ~op2; break;          // MVN
        }

        if (s)
        {
            m_regs.SetN(result >> 31);
            m_regs.SetZ(result == 0);
            if (opcode >= 0x2 && opcode <= 0x7 || opcode == 0xA || opcode == 0xB) {
                m_regs.SetC(aluCarry); // 算术指令使用减法器产生的 Carry
                m_regs.SetV(aluOverflow);
            } else {
                m_regs.SetC(carry);    // 逻辑指令使用移位器产生的 Carry
            }
        }
        if (writeResult)
        {
            m_regs.r[rd] = result;
            if (rd == 15)
            {
                if (s)
                {
                    // -------------------------------------------------------
                    // [v8 修复] ARM exception return（S=1, Rd=15）
                    //
                    // ARM 规范：当数据处理指令同时满足 S=1 且 Rd=15 时，
                    // 这是一条 "exception return" 指令（如 SUBS PC,R14_irq,#4）。
                    // 硬件行为：CPSR = SPSR（完整复制，含 T/I/F/Mode 位）
                    //           PC   = 计算结果（不依赖 result bit0 决定模式）
                    //
                    // 原代码缺陷：
                    //   - 只做了 SwitchMode(spsr & 0x1F)，仅切换了 mode 字段
                    //   - 用 result & 1 决定 T 位（SUBS PC,R14_irq,#4 结果为
                    //     0x08001AF4，bit0=0 → SetT(false)）
                    //   - SPSR_irq.T=1（IRQ 进入时 Thumb 模式）被丢弃
                    //
                    // 后果（日志证据）：
                    //   行6893：[IRQ] Enter PC=0x08001AF4 T=1（Thumb 模式进入）
                    //   IWRAMEntry step+084-088：PC 步长 +4（ARM 模式！）
                    //   → Thumb 代码被 ARM 误解码，0x08001B00 的两条 Thumb 字节
                    //     被解析成一条大跳转到 0x08A9BCAC（Sappy PCM mixer Thumb 区）
                    //   → Sappy mixer 以 ARM 模式执行 Thumb 代码，不产生 PCM 样本
                    //   → FIFO DMA Push 数据全零 → 无声
                    //
                    // 修复：完整将 SPSR 复制到 CPSR，用 SPSR.T 决定返回后的执行模式
                    // -------------------------------------------------------
                    uint32_t spsr_val = m_regs.spsr;
                    m_regs.SwitchMode(spsr_val & 0x1F); // 先切换 banked 寄存器组
                    m_regs.cpsr = spsr_val;            // 再完整覆盖 CPSR（含 T/I/F 位）
                    bool thumb_ret = (spsr_val >> 5) & 1;
                    if (thumb_ret)
                    {
                        m_regs.SetT(true);
                        m_regs.PC() = (result & ~1u) + 4;  // Thumb 流水线补偿
                    }
                    else
                    {
                        m_regs.SetT(false);
                        m_regs.PC() = (result & ~3u) + 8;  // ARM 流水线补偿
                    }
                }
                else
                {
                    // 普通写 PC（S=0, Rd=15）：bit0 决定 ARM/Thumb
                    uint32_t target = result & ~3u;
                    if (result & 1) { m_regs.SetT(true);  m_regs.PC() = target + 4; }
                    else            { m_regs.SetT(false); m_regs.PC() = target + 8; }
                }
            }
        }
        return 1;
    }

    // 内存访问指令（LDR/STR）
    if ((instr & 0x0C000000) == 0x04000000)
    {
        uint32_t rn     = (instr >> 16) & 0xF;
        uint32_t rd     = (instr >> 12) & 0xF;
        bool     load   = (instr >> 20) & 1;
        bool     byte   = (instr >> 22) & 1;
        bool     up     = (instr >> 23) & 1;
        bool     pre    = (instr >> 24) & 1;
        bool     wb     = (instr >> 21) & 1;
        bool     imm    = !((instr >> 25) & 1);

        uint32_t offset;
        bool carry = m_regs.C();
        if (imm)
            offset = instr & 0xFFF;
        else
        {
            uint32_t rm = instr & 0xF;
            uint32_t shiftType = (instr >> 5) & 3;
            uint32_t shiftAmt  = (instr >> 7) & 0x1F;
            offset = BarrelShift(GetReg(rm), shiftType, shiftAmt, carry);
        }

        // rn=15 时基址用 pc+8（ARM 流水线规范）
        uint32_t addr = GetReg(rn);
        if (pre) addr = up ? addr + offset : addr - offset;

        if (load)
        {
            m_regs.r[rd] = byte ? ReadByte(addr) : ReadWord(addr);
            if (rd == 15)
            {
                // LDR PC：视 bit0 决定模式，并补偿流水线
                uint32_t val = m_regs.r[rd];
                if (val & 1) { m_regs.SetT(true);  m_regs.PC() = (val & ~1u) + 4; }
                else         { m_regs.SetT(false); m_regs.PC() = (val & ~3u) + 8; }
            }
        }
        else
        {
            if (byte) WriteByte(addr, (uint8_t)m_regs.r[rd]);
            else      WriteWord(addr, m_regs.r[rd]);
        }

        if (!pre) addr = up ? addr + offset : addr - offset;
        if (wb || !pre) m_regs.r[rn] = addr;
        return load ? 3 : 2;
    }

    // 块传输（LDM/STM）
    // ARM 规范：无论 up/pre 方向如何，寄存器始终按升序写入升序地址。
    // 四种寻址模式的起始地址：
    //   IA (up=1,pre=0): start=base
    //   IB (up=1,pre=1): start=base+4
    //   DA (up=0,pre=0): start=base-count*4+4
    //   DB (up=0,pre=1): start=base-count*4   ← STMFD/LDMFD (PUSH/POP) 使用此模式
    if ((instr & 0x0E000000) == 0x08000000)
    {
        uint32_t rn    = (instr >> 16) & 0xF;
        bool     load  = (instr >> 20) & 1;
        bool     up    = (instr >> 23) & 1;
        bool     pre   = (instr >> 24) & 1;
        bool     wb    = (instr >> 21) & 1;
        bool     s_bit = (instr >> 22) & 1;  // [v8 修复] S bit：LDM S=1+PC = exception return
        uint16_t rlist = instr & 0xFFFF;
        bool     pc_in_list = (rlist >> 15) & 1;

        // rn=15 作基址时用 pc+8（ARM 流水线规范，LDM/STM with R15 as base 极罕见但需正确）
        uint32_t base = GetReg(rn);
        int count = 0;
        for (int i = 0; i < 16; i++) if (rlist & (1 << i)) count++;

        uint32_t addr;
        if (up)
            addr = pre ? base + 4 : base;
        else
            addr = pre ? base - (uint32_t)(count * 4)
                       : base - (uint32_t)(count * 4) + 4;

        for (int i = 0; i < 16; i++)
        {
            if (!(rlist & (1 << i))) continue;
            if (load)
            {
                m_regs.r[i] = ReadWord(addr);
                if (i == 15)
                {
                    uint32_t val = m_regs.r[15];
                    if (s_bit && pc_in_list)
                    {
                        // [v8 修复] LDM S=1 + PC in list = exception return
                        // ARM 规范：CPSR = SPSR（完整复制，含 T 位），PC = 加载值
                        // 与 Data Processing exception return 相同语义
                        uint32_t spsr_val = m_regs.spsr;
                        m_regs.SwitchMode(spsr_val & 0x1F);
                        m_regs.cpsr = spsr_val;
                        bool thumb_ret = (spsr_val >> 5) & 1;
                        if (thumb_ret)
                        {
                            m_regs.SetT(true);
                            m_regs.PC() = (val & ~1u) + 4;
                        }
                        else
                        {
                            m_regs.SetT(false);
                            m_regs.PC() = (val & ~3u) + 8;
                        }
                    }
                    else
                    {
                        // 普通 LDM PC：bit0 决定 ARM/Thumb（BX 语义）
                        if (val & 1) { m_regs.SetT(true);  m_regs.PC() = (val & ~1u) + 4; }
                        else         { m_regs.SetT(false); m_regs.PC() = (val & ~3u) + 8; }
                    }
                }
            }
            else
                WriteWord(addr, m_regs.r[i]);
            addr += 4; // 永远沿升序方向遍历块
        }

        if (wb)
            m_regs.r[rn] = up ? base + (uint32_t)(count * 4)
                               : base - (uint32_t)(count * 4);
        return count + 1;
    }

    // SWI — 先尝试软件模拟，无法处理时才跳 BIOS 向量
    if ((instr & 0x0F000000) == 0x0F000000)
    {
        uint8_t swiId = (uint8_t)((instr >> 16) & 0xFF);
        // SWI/ARM 已验证正常，v16 关闭
        // LogDebug(L"  [SWI/ARM] id=0x%02X PC=0x%08X ...", swiId, pc, ...);
        if (!HandleSWI(swiId))
        {
            // LR = SWI 下一条指令地址（pc+4），补偿已有的 += 4
            m_regs.LR() = pc + 4;
            // 跳 SWI 向量 0x08，+8 补偿流水线
            m_regs.SetT(false);
            m_regs.PC() = 0x00000008 + 8;
        }
        return 3;
    }

    // 未实现的指令：跳过
    return 1;
}

int GbaEmulator::ExecuteThumb()
{
    uint32_t pc = m_regs.PC() - 4; // Thumb 流水线：PC 超前 4 字节
    uint16_t instr = ReadHalf(pc);
    m_regs.PC() += 2;

    // Thumb 指令解码（简化实现）
    uint32_t op = instr >> 13;

    // 移位立即数
    if (op == 0 && ((instr >> 11) & 3) != 3)
    {
        uint32_t shiftType = (instr >> 11) & 3;
        uint32_t shiftAmt  = (instr >> 6) & 0x1F;
        uint32_t rs = (instr >> 3) & 7;
        uint32_t rd = instr & 7;
        bool carry = m_regs.C();
        m_regs.r[rd] = BarrelShift(m_regs.r[rs], shiftType, shiftAmt, carry);
        m_regs.SetN(m_regs.r[rd] >> 31);
        m_regs.SetZ(m_regs.r[rd] == 0);
        m_regs.SetC(carry);
        return 1;
    }

    // ADD/SUB 寄存器/立即数（Format 1：3位立即数或寄存器，始终更新 N/Z/C/V）
    if ((instr >> 11) == 0x3)
    {
        bool sub = (instr >> 9) & 1;
        bool imm = (instr >> 10) & 1;
        uint32_t rs = (instr >> 3) & 7;
        uint32_t rd = instr & 7;
        uint32_t rn  = m_regs.r[rs];
        uint32_t op2 = imm ? ((instr >> 6) & 7) : m_regs.r[(instr >> 6) & 7];
        if (sub)
        {
            // SUBS：减法，C=1 表示无借位（rn >= op2）
            m_regs.r[rd] = rn - op2;
            m_regs.SetC(rn >= op2);
            m_regs.SetV(((rn ^ op2) & (rn ^ m_regs.r[rd])) >> 31);
        }
        else
        {
            // ADDS：加法，C=1 表示无符号进位
            uint64_t res64 = (uint64_t)rn + op2;
            m_regs.r[rd] = (uint32_t)res64;
            m_regs.SetC(res64 > 0xFFFFFFFFu);
            m_regs.SetV((~(rn ^ op2) & (rn ^ m_regs.r[rd])) >> 31);
        }
        m_regs.SetN(m_regs.r[rd] >> 31);
        m_regs.SetZ(m_regs.r[rd] == 0);
        return 1;
    }

    // MOV/CMP/ADD/SUB 立即数（Format 3：8位立即数，始终更新 N/Z/C/V）
    if (op == 1)
    {
        uint32_t opcode = (instr >> 11) & 3;
        uint32_t rd     = (instr >> 8) & 7;
        uint32_t imm8   = instr & 0xFF;
        uint32_t rn     = m_regs.r[rd];
        switch (opcode)
        {
        case 0: // MOV：只更新 N/Z（无 C/V）
            m_regs.r[rd] = imm8;
            m_regs.SetN(0);
            m_regs.SetZ(imm8 == 0);
            return 1;
        case 1: // CMP：减法，更新全部 N/Z/C/V，不写回
        {
            uint32_t r = rn - imm8;
            m_regs.SetN(r >> 31);
            m_regs.SetZ(r == 0);
            m_regs.SetC(rn >= imm8);                          // 无借位
            m_regs.SetV(((rn ^ imm8) & (rn ^ r)) >> 31);     // 有符号溢出
            return 1;
        }
        case 2: // ADDS：加法，更新 N/Z/C/V，写回
        {
            uint64_t res64 = (uint64_t)rn + imm8;
            m_regs.r[rd] = (uint32_t)res64;
            m_regs.SetN(m_regs.r[rd] >> 31);
            m_regs.SetZ(m_regs.r[rd] == 0);
            m_regs.SetC(res64 > 0xFFFFFFFFu);
            m_regs.SetV((~(rn ^ imm8) & (rn ^ m_regs.r[rd])) >> 31);
            return 1;
        }
        case 3: // SUBS：减法，更新 N/Z/C/V，写回
        {
            m_regs.r[rd] = rn - imm8;
            m_regs.SetN(m_regs.r[rd] >> 31);
            m_regs.SetZ(m_regs.r[rd] == 0);
            m_regs.SetC(rn >= imm8);
            m_regs.SetV(((rn ^ imm8) & (rn ^ m_regs.r[rd])) >> 31);
            return 1;
        }
        }
        return 1;
    }

    // ALU 操作（Format 4）
    if ((instr >> 10) == 0x10)
    {
        uint32_t opcode = (instr >> 6) & 0xF;
        uint32_t rs = (instr >> 3) & 7;
        uint32_t rd = instr & 7;
        uint32_t rn  = m_regs.r[rd];
        uint32_t rop = m_regs.r[rs];
        bool carry = m_regs.C();
        switch (opcode)
        {
        case 0x0: m_regs.r[rd] &= rop; break; // AND
        case 0x1: m_regs.r[rd] ^= rop; break; // EOR
        case 0x2: m_regs.r[rd] = BarrelShift(rn, 0, rop & 0xFF, carry); break; // LSL
        case 0x3: m_regs.r[rd] = BarrelShift(rn, 1, rop & 0xFF, carry); break; // LSR
        case 0x4: m_regs.r[rd] = BarrelShift(rn, 2, rop & 0xFF, carry); break; // ASR
        case 0x5: // ADC: rd = rn + rs + C，更新 N/Z/C/V
        {
            uint64_t res64 = (uint64_t)rn + rop + (uint32_t)carry;
            m_regs.r[rd] = (uint32_t)res64;
            m_regs.SetN(m_regs.r[rd] >> 31);
            m_regs.SetZ(m_regs.r[rd] == 0);
            m_regs.SetC(res64 > 0xFFFFFFFFu);
            m_regs.SetV((~(rn ^ rop) & (rn ^ m_regs.r[rd])) >> 31);
            return 1;
        }
        case 0x6: // SBC: rd = rn - rs - (1-C)，更新 N/Z/C/V
        {
            uint32_t borrow = carry ? 0u : 1u;
            uint64_t res64  = (uint64_t)rn - rop - borrow;
            m_regs.r[rd] = (uint32_t)res64;
            m_regs.SetN(m_regs.r[rd] >> 31);
            m_regs.SetZ(m_regs.r[rd] == 0);
            // C=1 if no borrow: rn >= (rop + borrow) 无符号
            m_regs.SetC((uint64_t)rn >= (uint64_t)rop + borrow);
            m_regs.SetV(((rn ^ rop) & (rn ^ m_regs.r[rd])) >> 31);
            return 1;
        }
        case 0x7: m_regs.r[rd] = BarrelShift(rn, 3, rop & 0xFF, carry); break; // ROR
        case 0x8: // TST: N/Z 只，不写 C/V
        {
            uint32_t r = rn & rop;
            m_regs.SetN(r >> 31);
            m_regs.SetZ(r == 0);
            return 1;
        }
        case 0x9: // NEG: rd = 0 - rs，更新 N/Z/C/V（等效 RSB #0）
        {
            m_regs.r[rd] = 0u - rop;
            m_regs.SetN(m_regs.r[rd] >> 31);
            m_regs.SetZ(m_regs.r[rd] == 0);
            m_regs.SetC(rop == 0);  // 0-0=0 无借位；其他均借位
            m_regs.SetV((rop & m_regs.r[rd]) >> 31);
            return 1;
        }
        case 0xA: // CMP: rn - rs，不写回，更新 N/Z/C/V
        {
            uint32_t r = rn - rop;
            m_regs.SetN(r >> 31);
            m_regs.SetZ(r == 0);
            m_regs.SetC(rn >= rop);
            m_regs.SetV(((rn ^ rop) & (rn ^ r)) >> 31);
            return 1;
        }
        case 0xB: // CMN: rn + rs，不写回，更新 N/Z/C/V
        {
            uint64_t res64 = (uint64_t)rn + rop;
            uint32_t r = (uint32_t)res64;
            m_regs.SetN(r >> 31);
            m_regs.SetZ(r == 0);
            m_regs.SetC(res64 > 0xFFFFFFFFu);
            m_regs.SetV((~(rn ^ rop) & (rn ^ r)) >> 31);
            return 1;
        }
        case 0xC: m_regs.r[rd] |= rop; break;  // ORR
        case 0xD: m_regs.r[rd] *= rop; break;  // MUL（flag 由下方通用路径设置）
        case 0xE: m_regs.r[rd] &= ~rop; break; // BIC
        case 0xF: m_regs.r[rd] = ~rop; break;  // MVN
        }
        // 通用路径：AND/EOR/LSL/LSR/ASR/ROR/ORR/MUL/BIC/MVN 更新 N/Z/C（C 来自移位器）
        m_regs.SetN(m_regs.r[rd] >> 31);
        m_regs.SetZ(m_regs.r[rd] == 0);
        m_regs.SetC(carry);
        return 1;
    }

    // LDR/STR 立即数偏移
    if (op == 3)
    {
        bool     load  = (instr >> 11) & 1;
        bool     byte  = (instr >> 12) & 1;
        uint32_t offset = ((instr >> 6) & 0x1F) << (byte ? 0 : 2);
        uint32_t rb = (instr >> 3) & 7;
        uint32_t rd = instr & 7;
        uint32_t addr = m_regs.r[rb] + offset;
        if (load)
            m_regs.r[rd] = byte ? ReadByte(addr) : ReadWord(addr);
        else
        {
            if (byte) WriteByte(addr, (uint8_t)m_regs.r[rd]);
            else      WriteWord(addr, m_regs.r[rd]);
        }
        return load ? 3 : 2;
    }

    // PUSH/POP (Format 14)
    // ARM7TDMI 编码：PUSH bits[15:9]=1011010, POP bits[15:9]=1011110
    // 0xB4/0xB5 = PUSH（不含/含LR），0xBC/0xBD = POP（不含/含PC）
    // 注意：不能用 (instr>>12)==0xB，那样会误匹配 Format 13（ADD/SUB SP = 0xB0xx/0xB1xx）
    if ((instr >> 9) == 0x5A || (instr >> 9) == 0x5E)
    {
        bool load = (instr >> 11) & 1;
        bool lr_pc = (instr >> 8) & 1;
        uint8_t rlist = instr & 0xFF;
        if (load) // POP
        {
            for (int i = 0; i < 8; i++)
                if (rlist & (1 << i)) { m_regs.r[i] = ReadWord(m_regs.SP()); m_regs.SP() += 4; }
            if (lr_pc)
            {
                // POP {PC}：弹出返回地址，bit0 决定 ARM/Thumb，并补偿流水线
                uint32_t val = ReadWord(m_regs.SP()); m_regs.SP() += 4;
                if (val & 1) { m_regs.SetT(true);  m_regs.PC() = (val & ~1u) + 4; }
                else         { m_regs.SetT(false); m_regs.PC() = (val & ~3u) + 8; }
            }
        }
        else // PUSH
        {
            if (lr_pc) { m_regs.SP() -= 4; WriteWord(m_regs.SP(), m_regs.LR()); }
            for (int i = 7; i >= 0; i--)
                if (rlist & (1 << i)) { m_regs.SP() -= 4; WriteWord(m_regs.SP(), m_regs.r[i]); }
        }
        return 1;
    }

    // Thumb B 条件分支
    // 规范：target = (pc + 4) + SignExtend(imm8)*2
    // 下次 ExecuteThumb 取指：PC - 4。要使取指地址 = target，需 PC = target + 4。
    if ((instr >> 12) == 0xD)
    {
        uint32_t cond = (instr >> 8) & 0xF;
        if (CheckCondition(cond))
        {
            int32_t offset = (int32_t)(int8_t)(instr & 0xFF) * 2;
            uint32_t target = (pc + 4) + (uint32_t)offset;
            m_regs.PC() = target + 4; // 补偿流水线
        }
        return 1;
    }
    // Thumb B 无条件分支（unconditional）
    if ((instr >> 11) == 0x1C)
    {
        int32_t offset = (int32_t)((instr & 0x7FF) << 21) >> 20;
        uint32_t target = (pc + 4) + (uint32_t)offset;
        m_regs.PC() = target + 4;
        return 1;
    }

    // Thumb BL（两条 16-bit 指令组合，ARM7TDMI 规范）
    // 第一条（H=10, bits[15:11]=0x1E）：LR = (pc+4) + SignExtend(imm11)<<12
    // 注：pc+4 是 Thumb 流水线 PC（当前执行地址+4）
    if ((instr >> 11) == 0x1E)
    {
        int32_t offset = (int32_t)((instr & 0x7FF) << 21) >> 9; // SignExtend(imm11)<<12
        m_regs.LR() = (pc + 4) + (uint32_t)offset;
        return 1;
    }
    // 第二条 BL suffix（H=11, bits[15:11]=0x1F）：Thumb->Thumb 调用，始终保持 Thumb 模式
    // ARM7TDMI 规范：Thumb BL 不做 ARM/Thumb 切换，目标地址 bit0 仅用于区分 BL/BLX，
    // 在纯 BL (0x1F) 中忽略 bit0，无论奇偶都保持 Thumb 模式。
    // 仅 Thumb BLX suffix（H=01, bits[15:11]=0x1D，ARMv5T 引入）才切换到 ARM 模式。
    if ((instr >> 11) == 0x1F)
    {
        uint32_t target = m_regs.LR() + ((instr & 0x7FF) << 1);
        m_regs.LR() = (pc + 2) | 1u; // 返回地址 = 下一条 Thumb 指令地址（bit0=1 标记 Thumb）
        m_regs.SetT(true);            // 始终保持 Thumb 模式
        m_regs.PC() = (target & ~1u) + 4; // 补偿 Thumb 流水线：下次取指 pc = PC-4 = target
        return 3;
    }
    // Thumb BLX suffix（H=01, bits[15:11]=0x1D）：Thumb->ARM 调用（ARMv5T，GBA/ARM7TDMI 不支持）
    // ARM7TDMI 不实现此指令，但若遇到 0x1D 编码需跳过而不是误执行
    if ((instr >> 11) == 0x1D)
    {
        // ARM7TDMI 无此指令，作为 UNDEFINED 处理（跳过）
        return 1;
    }

    // Thumb BX（寄存器跳转，可切换 ARM/Thumb）
    // Thumb 规范：rs=15 时，PC 值 = 当前执行地址+4（Thumb 流水线）
    if ((instr & 0xFF87) == 0x4700)
    {
        uint32_t rs = (instr >> 3) & 0xF;
        uint32_t addr = (rs == 15u) ? (pc + 4u) : m_regs.r[rs];
        uint32_t target = addr & ~1u;
        if (addr & 1) { m_regs.SetT(true);  m_regs.PC() = target + 4; }
        else          { m_regs.SetT(false); m_regs.PC() = target + 8; }

        // -------------------------------------------------------
        // [v10A 修复] BX 目标为未初始化 IWRAM（全零）时注入空函数返回
        // [v14 修复B] 额外打印 IWRAM 首 8 字节内容供诊断。
        // -------------------------------------------------------
        if ((target >> 24) == 0x03u)
        {
            if (ReadHalf(target)       == 0x0000u &&
                ReadHalf(target + 2u)  == 0x0000u &&
                ReadHalf(target + 4u)  == 0x0000u)
            {
                uint32_t lr = m_regs.LR();
                LogDebug(L"[CPU:BX-NULL-IWRAM] Thumb BX→0x%08X 目标 IWRAM 全零（未初始化）"
                         L" IWRAM[+0..+7]=0x%08X 0x%08X 注入空函数返回 LR=0x%08X T=%d",
                         target, ReadWord(target), ReadWord(target + 4u),
                         lr, (int)((lr & 1u) != 0u));
                uint32_t retTarget = lr & ~1u;
                if (lr & 1u) { m_regs.SetT(true);  m_regs.PC() = retTarget + 4u; }
                else         { m_regs.SetT(false); m_regs.PC() = retTarget + 8u; }
            }
        }
        return 3;
    }

    // MOV/ADD/CMP Hi 寄存器（rs 可为 8-15 高寄存器）
    // Thumb 规范：rs=15 时读值为执行地址+4（Thumb 流水线 PC）
    if ((instr >> 10) == 0x11)
    {
        uint32_t opcode = (instr >> 8) & 3;
        uint32_t rs = (instr >> 3) & 0xF;
        uint32_t rd = (instr & 7) | ((instr >> 4) & 8);
        uint32_t rsVal = (rs == 15u) ? (pc + 4u) : m_regs.r[rs];
        switch (opcode)
        {
        case 0: m_regs.r[rd] += rsVal; break; // ADD
        case 1: // CMP Hi reg：减法，更新 N/Z/C/V，不写回
        {
            uint32_t r = m_regs.r[rd] - rsVal;
            m_regs.SetN(r >> 31);
            m_regs.SetZ(r == 0);
            m_regs.SetC(m_regs.r[rd] >= rsVal);
            m_regs.SetV(((m_regs.r[rd] ^ rsVal) & (m_regs.r[rd] ^ r)) >> 31);
            return 1;
        }
        case 2: m_regs.r[rd] = rsVal; break;  // MOV
        }
        if (rd == 15)
        {
            // ARMv4T Thumb Format 5: MOV/ADD 写 PC 时，保持当前 Thumb 模式（不切换）
            // 与 BX 不同：BX 通过 bit0 切换 ARM/Thumb；MOV/ADD Hi 只是分支，不改变 T 位
            // PC 补偿：Thumb 流水线 +4（忽略 bit0，直接对齐）
            m_regs.PC() = (m_regs.r[15] & ~1u) + 4;
        }
        return 1;
    }

    // LDR PC 相对（Thumb Format 9）
    // ARM 规范：addr = (PC_pipeline & ~3) + imm8*4
    //   PC_pipeline = 当前执行地址 + 4（Thumb 流水线）
    // 此时 ExecuteThumb 已：pc = m_regs.PC() - 4，随后 m_regs.PC() += 2，
    // 故 m_regs.PC() = 执行地址 + 6，PC_pipeline = m_regs.PC() - 2 = 执行地址 + 4。
    if ((instr >> 11) == 0x9)
    {
        uint32_t rd     = (instr >> 8) & 7;
        uint32_t offset = (instr & 0xFF) << 2;
        uint32_t addr = ((m_regs.PC() - 2u) & ~3u) + offset;
        m_regs.r[rd] = ReadWord(addr);
        // LDR PC-rel 已验证正常，v16 关闭
        // LogDebug(L"[Thumb] LDR PC-rel rd=r%d execPC=0x%08X val=0x%08X", rd, pc, m_regs.r[rd]);
        return 3;
    }

    // Thumb SWI — 先尝试软件模拟
    if ((instr >> 8) == 0xDF)
    {
        uint8_t swiId = (uint8_t)(instr & 0xFF);
        // SWI/Thumb 已验证正常，v16 关闭
        // LogDebug(L"  [SWI/Thumb] id=0x%02X PC=0x%08X", swiId, pc);
        if (!HandleSWI(swiId))
        {
            // LR = SWI 下一条指令地址（pc+2），此时 m_regs.PC() = pc+6（已+2）
            m_regs.LR() = pc + 2;
            m_regs.SetT(false);
            // 跳 SWI 向量 0x08，+8 补偿 ARM 流水线
            m_regs.PC() = 0x00000008 + 8;
        }
        return 3;
    }

    // -----------------------------------------------------------------------
    // Thumb Format 10: STRH/LDRH with immediate offset
    // 1000 L [imm5] [Rb] [Rd]   offset = imm5 * 2
    // 这是 DMA CNT_H 写入的核心指令，必须实现！
    // -----------------------------------------------------------------------
    if ((instr >> 12) == 0x8)
    {
        bool     load   = (instr >> 11) & 1;
        uint32_t offset = ((instr >> 6) & 0x1F) << 1; // imm5 * 2
        uint32_t rb     = (instr >> 3) & 7;
        uint32_t rd     = instr & 7;
        uint32_t addr   = m_regs.r[rb] + offset;
        if (load)
            m_regs.r[rd] = (uint32_t)ReadHalf(addr);
        else
            WriteHalf(addr, (uint16_t)m_regs.r[rd]);
        return load ? 3 : 2;
    }

    // -----------------------------------------------------------------------
    // Thumb Format 7: STR/LDR with register offset (word/byte)
    // 0101 L B 0 [Ro] [Rb] [Rd]
    // -----------------------------------------------------------------------
    if ((instr >> 12) == 0x5 && !((instr >> 9) & 1))
    {
        bool     load = (instr >> 11) & 1;
        bool     byte = (instr >> 10) & 1;
        uint32_t ro   = (instr >> 6) & 7;
        uint32_t rb   = (instr >> 3) & 7;
        uint32_t rd   = instr & 7;
        uint32_t addr = m_regs.r[rb] + m_regs.r[ro];
        if (load)
            m_regs.r[rd] = byte ? (uint32_t)ReadByte(addr) : ReadWord(addr);
        else
        {
            if (byte) WriteByte(addr, (uint8_t)m_regs.r[rd]);
            else      WriteWord(addr, m_regs.r[rd]);
        }
        return load ? 3 : 2;
    }

    // -----------------------------------------------------------------------
    // Thumb Format 8: STRH/LDRH/LDRSB/LDRSH with register offset
    // 0101 H S 1 [Ro] [Rb] [Rd]
    //   H=0,S=0 → STRH   H=0,S=1 → LDRSB
    //   H=1,S=0 → LDRH   H=1,S=1 → LDRSH
    // -----------------------------------------------------------------------
    if ((instr >> 12) == 0x5 && ((instr >> 9) & 1))
    {
        bool     H    = (instr >> 11) & 1;
        bool     S    = (instr >> 10) & 1;
        uint32_t ro   = (instr >> 6) & 7;
        uint32_t rb   = (instr >> 3) & 7;
        uint32_t rd   = instr & 7;
        uint32_t addr = m_regs.r[rb] + m_regs.r[ro];
        if (!H && !S) // STRH
        {
            WriteHalf(addr, (uint16_t)m_regs.r[rd]);
            return 2;
        }
        else if (!H && S) // LDRSB
        {
            m_regs.r[rd] = (uint32_t)(int32_t)(int8_t)ReadByte(addr);
            return 3;
        }
        else if (H && !S) // LDRH
        {
            m_regs.r[rd] = (uint32_t)ReadHalf(addr);
            return 3;
        }
        else // LDRSH
        {
            m_regs.r[rd] = (uint32_t)(int32_t)(int16_t)ReadHalf(addr);
            return 3;
        }
    }

    // -----------------------------------------------------------------------
    // Thumb Format 11: SP-relative STR/LDR
    // 1001 L [Rd] [imm8]   addr = SP + imm8*4
    // -----------------------------------------------------------------------
    if ((instr >> 12) == 0x9)
    {
        bool     load   = (instr >> 11) & 1;
        uint32_t rd     = (instr >> 8) & 7;
        uint32_t offset = (instr & 0xFF) << 2; // imm8 * 4
        uint32_t addr   = m_regs.SP() + offset;
        if (load)
            m_regs.r[rd] = ReadWord(addr);
        else
            WriteWord(addr, m_regs.r[rd]);
        return load ? 3 : 2;
    }

    // -----------------------------------------------------------------------
    // Thumb Format 12: Load address (ADD Rd, PC/SP, #imm8*4)
    // 1010 S [Rd] [imm8]   S=0→PC, S=1→SP
    // -----------------------------------------------------------------------
    if ((instr >> 12) == 0xA)
    {
        bool     sp     = (instr >> 11) & 1;
        uint32_t rd     = (instr >> 8) & 7;
        uint32_t offset = (instr & 0xFF) << 2;
        uint32_t base   = sp ? m_regs.SP() : ((pc + 4) & ~3u);
        m_regs.r[rd]    = base + offset;
        return 1;
    }

    // -----------------------------------------------------------------------
    // Thumb Format 13: Add offset to SP  (1011 0000 S [imm7])
    // ADDS SP, SP, #±imm7*4
    // -----------------------------------------------------------------------
    if ((instr >> 8) == 0xB0)
    {
        bool     neg    = (instr >> 7) & 1;
        uint32_t offset = (instr & 0x7F) << 2;
        if (neg) m_regs.SP() -= offset;
        else     m_regs.SP() += offset;
        return 1;
    }

    // -----------------------------------------------------------------------
    // Thumb STM/LDM (Format 15): 1100 L [Rb] [rlist]
    // -----------------------------------------------------------------------
    if ((instr >> 12) == 0xC)
    {
        bool     load  = (instr >> 11) & 1;
        uint32_t rb    = (instr >> 8) & 7;
        uint8_t  rlist = (uint8_t)(instr & 0xFF);
        uint32_t addr  = m_regs.r[rb];
        if (load)
        {
            for (int i = 0; i < 8; i++)
                if (rlist & (1 << i)) { m_regs.r[i] = ReadWord(addr); addr += 4; }
        }
        else
        {
            for (int i = 0; i < 8; i++)
                if (rlist & (1 << i)) { WriteWord(addr, m_regs.r[i]); addr += 4; }
        }
        m_regs.r[rb] = addr; // write-back
        return 1;
    }

    // 未知指令：记录并跳过（便于调试）
    LogDebug(L"  [UnknownThumb] PC=0x%08X instr=0x%04X (skipped)", pc, instr);
    return 1;
}

void GbaEmulator::HandleInterrupt()
{
    // GBA 硬件规范：HALT 由任意 IF 位置位解除，不检查 IE 或 IME
    // 只要有中断挂起（IF != 0），即可唤醒 CPU，然后再由 IME+IE 决定是否跳向量
    if (m_halted && m_irq.ifl) {
        // IRQ HALT released 已验证正常，v16 关闭
        // LogDebug(L"[IRQ] HALT released: IF=0x%04X IE=0x%04X IME=%d", m_irq.ifl, m_irq.ie, (int)m_irq.ime);
        m_halted = false;
    }

    // 以下才检查 IME/IE，决定是否跳转到 IRQ 向量
    uint16_t pending = m_irq.ie & m_irq.ifl;
    if (!m_irq.ime || !pending) return;

    // -------------------------------------------------------
    // [v5 修复] CPSR.I bit（第7位）检查 —— 防止嵌套 IRQ
    //
    // ARM7TDMI 规范：进入 IRQ 模式后 CPSR.I=1（行 1704 设置）。
    // 此后每个 CPU step 仍会调用 HandleInterrupt；若不检查 I bit，
    // 会在 BIOS IRQ stub（0x00000128）执行中途再次进入，导致：
    //   ① STMFD SP!,{...} 被执行两次 → 栈指针额外偏移 -24，栈数据错误
    //   ② BX R0（跳 SoundMain）永远无法到达 → SoundMain 不被调用
    //   ③ SoundMain 不执行 → PCM 缓冲全零 → FIFO current_sample=0 → 完全静音
    //
    // 根据日志：行6894 第1次 IRQ Enter（游戏 Thumb 代码被打断），
    //           行6897 第2次 IRQ Enter（PC=0x00000128，BIOS 0x130 处被重入）
    // 本修复确保 CPSR.I=1 期间 HandleInterrupt 立即返回，不再重入。
    // -------------------------------------------------------
    if (m_regs.cpsr & (1u << 7)) return;

    // 进入 IRQ 模式（ARM7TDMI 规范）
    uint32_t oldCpsr = m_regs.cpsr;
    // ARM 模式：LR_irq = 被打断地址 + 4（PC - 8 + 4 = PC - 4）
    // Thumb 模式：LR_irq = 被打断地址 + 4（PC - 4 + 4 = PC）
    uint32_t returnAddr = m_regs.T() ? m_regs.PC() : m_regs.PC() - 4u;

    // -------------------------------------------------------
    // BIOS IRQ stub 行为：
    //   IWRAM[0x03007FF8] |= pending  → 写入 BIOS interrupt flags 镜像
    // 游戏的 IRQ handler / SWI IntrWait 通过读取 0x03007FF8 判断哪些中断已处理
    // -------------------------------------------------------
    uint16_t biosFlags = ReadHalf(0x03007FF8);
    WriteHalf(0x03007FF8, biosFlags | pending);
    // IRQ 入口日志已验证正常，v16 关闭
    // LogDebug(L"[IRQ] Enter: pending=0x%04X PC=0x%08X ...", ...);

    m_regs.SwitchMode(0x12); // 切换到 IRQ 模式
    m_regs.spsr = oldCpsr;
    m_regs.SetT(false);
    m_regs.cpsr |= (1u << 7); // 禁用 IRQ（防止嵌套）

    m_regs.r[14] = returnAddr;
    m_regs.r[15] = 0x18 + 8; // 跳转 IRQ 向量 0x00000018，+8 补偿 ARM 流水线
}

int GbaEmulator::RunForSamples(int16_t* buffer, int maxSamples)
{
    if (m_rom.empty()) return 0;

    // Frame 头日志已验证正常，v16 关闭
    // if (m_frameCount < 10) { LogDebug(L"GbaEmulator::RunForSamples: Frame %d ...", ...); }

    // GBA 扫描线时序（跨帧连续，不可每帧重置）：
    //   280896 周期/帧 = 228 条扫描线 × 1232 周期/线
    //   VCOUNT 0-159: VDraw（可见区）
    //   VCOUNT 160-227: VBlank
    //   VBlank IRQ 在 VCOUNT 从 159 → 160 时边沿触发
    //
    // ⚠️ 关键：VCOUNT 必须用 m_cycleAccum（全局累积）计算，绝不能每帧重置！
    //   游戏代码经常跨帧轮询 VCOUNT，若每帧重置为 0 则游戏永久死循环。
    static constexpr int GBA_CYCLES_PER_LINE = 1232;
    static constexpr int GBA_VBLANK_LINE     = 160;
    static constexpr int GBA_TOTAL_LINES     = 228;

    int samplesGenerated = 0;

    // ⚠️ 关键修复：不能用 cyclesToRun = GBA_CYCLES_PER_FRAME 作为主循环退出条件！
    // 原因：GBA_CYCLES_PER_FRAME = 228 * 1232 = 280896，恰好整除一帧的扫描线数，
    // 导致每次调用结束时 m_cycleAccum 是 280896 的整数倍，下次调用 VCOUNT 精确归零，
    // 游戏的 VCOUNT 轮询死循环永远无法跨帧退出。
    //
    // 正确做法：只按 APU 样本数退出（samplesGenerated < maxSamples），
    // 加一个安全上限（4 帧）防止 APU 完全静止时无限循环。
    const int maxCyclesPerCall = GBA_CYCLES_PER_FRAME * 4;
    int cyclesThisCall = 0;

    // 调试：对 PC=0x08000500-0x0800055F 范围内的每条指令进行逐步追踪
    static bool s_loopTracking   = false;
    static int  s_loopTrackCount = 0;
    static bool s_loopDone       = false;

    // 调试：追踪退出 VCOUNT=0x9F 死循环后的执行路径（前 60 步）
    static bool s_exitTracking   = false;
    static int  s_exitTrackCount = 0;
    static bool s_exitDone       = false;

    // 调试：完整清零循环退出后，追踪后续 1500 步（定位 Timer3 初始化）
    // 触发条件：PC 离开整个循环区域（0x08000588-0x08000596）
    static bool s_afterLoopTracking  = false;
    static int  s_afterLoopCount     = 0;
    static bool s_afterLoopDone      = false;
    static bool s_prevInFullLoop     = false;  // 覆盖内层+外层循环体范围

    // 强制清零循环退出标志
    static bool s_loopEscapeDone     = false;  // 第一/第二层循环（只触发一次）
    static bool s_loop3EscapeDone    = false;  // 第三层循环（首次触发后改为多次，仅日志去重）
    static bool s_postReturnTracking = false;  // ROM调用方返回后追踪
    static int  s_postReturnCount    = 0;
    static bool s_postReturnDone     = false;
    static bool s_iwramEntryTracking = false; // IWRAM首次进入追踪
    static int  s_iwramEntryCount    = 0;
    static bool s_iwramEntryDone     = false;
    static uint32_t s_lastPC         = 0;
    // [v10B] 连续 0x0000 指令（NOP 海）计数器
    // 防止 CPU 在未初始化内存漫游时无限空转（v10A BX 检测的后备保险）
    static int  s_nopSeaCount        = 0;

    // -----------------------------------------------------------------------
    // [v16] m4aOpenSong 异步注入 — 启动阶段
    // 触发：WriteWord 检测到 EWRAM magic 写入 → s_m4aPending=true
    // 修复A：扫描 EWRAM 找有效 Sappy 歌曲结构，调用 m4aOpenSong(songPtr) @ 0x08002DAC。
    //         歌曲结构判定：byte[0]=trackCount ∈ [1,16]，后跟 trackCount 个 ROM 指针
    //         （每个 4 字节，地址范围 0x08000000~0x0DFFFFFF）。
    //         删除对 0x0802E0E8 的调用——该地址是游戏任务管理器，不是 Sappy 函数。
    // 修复B'：agbMixer 复制大小 0x200 → 0x400 字节，防止 NOP-SEA 越界（越界点 0x0300031A）。
    // -----------------------------------------------------------------------
    if (s_m4aPending && !s_injecting)
    {
        s_m4aPending  = false;
        // v17: 不再全局锁定，注入完成后 s_m4aInjected 无需设 true
        s_injecting   = true;
        s_injectSteps = 0;

        // m4aOpenSong @ 0x08002DAC（Thumb，流水线 +4 → PC=0x08002DB0）
        const uint32_t kFuncAddr   = 0x08002DACu;
        const uint32_t kSentinelLR = 0x02000001u; // EWRAM 零页 + Thumb bit

        // 保存原 CPU 上下文（注入完成后恢复）
        s_savedPC     = m_regs.PC();
        s_savedLR     = m_regs.LR();
        s_savedR0     = m_regs.r[0];
        s_savedR2     = m_regs.r[2];
        s_savedCPSR   = m_regs.cpsr;
        s_savedSPSR   = m_regs.spsr;
        s_savedHalted = m_halted;

        LogDebug(L"[v21] ===== m4aOpenSong 异步注入启动 =====");
        LogDebug(L"[v21] 原 CPU: PC=0x%08X LR=0x%08X CPSR=0x%08X T=%d halted=%d",
                 m_regs.PC(), m_regs.LR(), m_regs.cpsr, (int)m_regs.T(), (int)m_halted);
        uint32_t sappyBase = ReadWord(0x03007FF0u);
        LogDebug(L"[v21] 注入前 Sappy(@0x%08X): magic=0x%08X songField=0x%08X",
                 sappyBase, ReadWord(sappyBase), ReadWord(sappyBase + 8u));
        LogDebug(L"[v21] 注入前 Sappy: status=0x%02X vol=0x%02X ch0b0=0x%02X ch0b1=0x%02X",
                 ReadByte(sappyBase + 10u), ReadByte(sappyBase + 11u),
                 ReadByte(sappyBase + 0x40u), ReadByte(sappyBase + 0x41u));

        LogDebug(L"[v21] 注入前 游戏R2=0x%08X（=0x80则7步早返回）", m_regs.r[2]);
        LogDebug(L"[v21] sappyBase dump[00..1F]: %08X %08X %08X %08X %08X %08X %08X %08X",
                 ReadWord(sappyBase+0x00u), ReadWord(sappyBase+0x04u),
                 ReadWord(sappyBase+0x08u), ReadWord(sappyBase+0x0Cu),
                 ReadWord(sappyBase+0x10u), ReadWord(sappyBase+0x14u),
                 ReadWord(sappyBase+0x18u), ReadWord(sappyBase+0x1Cu));
        // -----------------------------------------------------------------------
        // [v17 修复B'] agbMixer IWRAM 修复（0x400 字节，v15 已验证有效）
        // -----------------------------------------------------------------------
        {
            uint32_t mixWord = ReadWord(0x03000000u);
            if (mixWord == 0x00000000u)
            {
                LogDebug(L"[v17 修复B'] IWRAM[0x03000000] 全零，从 ROM[0x08000F58] 复制 0x400 字节");
                const uint32_t kMixerSrc  = 0x08000F58u;
                const uint32_t kMixerDst  = 0x03000000u;
                const uint32_t kMixerSize = 0x400u;
                for (uint32_t i = 0; i < kMixerSize; i++)
                    WriteByte(kMixerDst + i, ReadByte(kMixerSrc + i));
                LogDebug(L"[v17 修复B'] 复制完成，IWRAM[0x03000000..+7]=0x%08X 0x%08X",
                         ReadWord(0x03000000u), ReadWord(0x03000004u));
            }
            // agbMixer 已在 IWRAM 时无需重复复制
        }

        // -----------------------------------------------------------------------
        // [v17 修复A] EWRAM 扫描：寻找有效 Sappy 歌曲结构（v15 已验证找到正确 songPtr）
        // -----------------------------------------------------------------------
        uint32_t songPtr = 0u;
        {
            const uint32_t kEwramStart = 0x02001000u;
            const uint32_t kEwramEnd   = 0x0203FFFFu;
            LogDebug(L"[v17 修复A] 扫描 EWRAM 0x%08X~0x%08X 寻找有效歌曲结构...",
                     kEwramStart, kEwramEnd);

            for (uint32_t addr = kEwramStart; addr + 8u <= kEwramEnd && songPtr == 0u; addr += 4u)
            {
                uint8_t trackCount = ReadByte(addr);
                if (trackCount < 1u || trackCount > 16u)
                    continue;

                // 检查后续 trackCount 个指针是否都指向 ROM
                bool valid = true;
                for (uint8_t t = 0; t < trackCount; t++)
                {
                    uint32_t tPtr = ReadWord(addr + 4u + (uint32_t)t * 4u);
                    uint8_t  hi   = (uint8_t)(tPtr >> 24);
                    if (hi < 0x08u || hi > 0x0Du)
                    {
                        valid = false;
                        break;
                    }
                }
                if (valid)
                {
                    songPtr = addr;
                    LogDebug(L"[v17 修复A] 找到有效歌曲结构 @ 0x%08X: trackCount=%d reverb=0x%02X ptr0=0x%08X",
                             addr, (int)trackCount, (int)ReadByte(addr + 2u),
                             ReadWord(addr + 4u));
                }
            }

            if (songPtr == 0u)
            {
                LogDebug(L"[v17 修复A] 未找到有效歌曲结构，注入取消");
                // 回滚注入状态，不执行 m4aOpenSong
                s_injecting   = false;
                m_regs.PC()   = s_savedPC;
                m_regs.LR()   = s_savedLR;
                m_regs.r[0]   = s_savedR0;
                m_regs.cpsr   = s_savedCPSR;
                m_regs.spsr   = s_savedSPSR;
                m_halted      = s_savedHalted;
                goto injection_skipped;
            }
        }

        // -----------------------------------------------------------------------
        // [v17 修复1] 重置 magic → 0x68736D53
        // v15 根因：SoundDriverMain 在 PC=0x08000EE4 执行 STR R3,[R0]（0x6003），
        //   将 magic+1 写回（0x68736D53 → 0x68736D54）。
        //   m4aOpenSong 入口 CMP magic, #0x68736D53 失败 → BNE 早返回（27步）。
        // 注：v13 也加了此修复，但当时 songPtr 的 trackCount=193（无效），仍早返回。
        //   v16 songPtr 已通过 EWRAM 扫描验证（trackCount ∈ [1,16]），两项同时满足。
        // -----------------------------------------------------------------------
        {
            uint32_t curMagic = ReadWord(sappyBase);
            if (curMagic != 0x68736D53u)
            {
                WriteWord(sappyBase, 0x68736D53u);
                LogDebug(L"[v17 修复1] magic 0x%08X → 0x68736D53（重置，确保 m4aOpenSong 入口检查通过）",
                         curMagic);
            }
        }

        // 重定向 CPU → m4aOpenSong(songPtr)
        m_regs.r[0]  = songPtr;         // 参数：歌曲结构指针
        m_regs.r[2]  = 0xFFu;           // [v21] 避免 CMP R2,#0x80/BEQ 早返回
        m_regs.r[1]  = 0x03u;           // [v21] 让 Step15 CMP R0(=3),R1(=3)→Z=1→BNE 不跳→执行 0x08002DCE
        m_regs.PC()  = kFuncAddr + 4u;  // Thumb 流水线 +4
        m_regs.LR()  = kSentinelLR;     // 哨兵返回地址
        m_regs.SetT(true);              // Thumb 模式
        m_halted     = false;

        LogDebug(L"[v21] PC 重定向 → 0x%08X（m4aOpenSong），R0=0x%08X R1=3（BNE修复）R2=0xFF（早返回修复），"
                 L"哨兵 LR=0x%08X，开始异步执行",
                 kFuncAddr, songPtr, kSentinelLR);
    }
    injection_skipped:;

    while (samplesGenerated < maxSamples && cyclesThisCall < maxCyclesPerCall)
    {
        int step = 0;
        if (!m_halted)
        {
            uint32_t currentInstrPC = m_regs.PC() - (m_regs.T() ? 4u : 8u);

            // -------------------------------------------------------
            // CPU 跑飞检测：PC 进入无效内存区域
            // GBA 有效地址范围：
            //   BIOS  0x00000000-0x00003FFF
            //   EWRAM 0x02000000-0x0203FFFF
            //   IWRAM 0x03000000-0x03007FFF
            //   IO    0x04000000-0x040003FF
            //   ROM   0x08000000-0x0DFFFFFF
            // 其他区域（含 0xFDxxxxxx）均视为跑飞。
            // -------------------------------------------------------
            {
                uint32_t region = currentInstrPC >> 24;
                bool validRegion = (region == 0x00 || region == 0x02 || region == 0x03 ||
                                    region == 0x04 || (region >= 0x08 && region <= 0x0D));
                if (!validRegion)
                {
                    LogDebug(L"[CPU:RUNAWAY] PC=0x%08X REGION=0x%02X T=%d "
                             L"R0=%08X R1=%08X R2=%08X R3=%08X "
                             L"R4=%08X R5=%08X R6=%08X R7=%08X "
                             L"LR=%08X SP=%08X CPSR=%08X "
                             L"IME=%d IE=0x%04X IF=0x%04X "
                             L"Timer0(en=%d reload=0x%04X) Timer1(en=%d reload=0x%04X)",
                             currentInstrPC, region, (int)m_regs.T(),
                             m_regs.r[0], m_regs.r[1], m_regs.r[2], m_regs.r[3],
                             m_regs.r[4], m_regs.r[5], m_regs.r[6], m_regs.r[7],
                             m_regs.LR(), m_regs.SP(), m_regs.cpsr,
                             (int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl,
                             (int)m_timers[0].enabled, m_timers[0].reload,
                             (int)m_timers[1].enabled, m_timers[1].reload);
                    // RUNAWAY 回收：将 PC 重定向到 BIOS 安全地址（HALT 等待 IRQ）
                    m_regs.SetT(false);
                    m_regs.PC() = 0x00000008u + 8u; // BIOS SWI stub: MOV PC, LR
                    m_halted = true;
                    s_nopSeaCount = 0; // 重置 NOP 海计数器
                    // 不 break，让循环继续以 HALT 模式积累周期，防止返回 0 样本
                }
            }

            // -------------------------------------------------------
            // [v10B 修复] 连续 0x0000 指令（NOP 海）检测
            //
            // 当 v10A BX-NULL-IWRAM 检测无法覆盖的路径（如 LDR PC 等间接跳转）
            // 进入未初始化内存区域时，CPU 会执行连续的 Thumb 0x0000（MOVS R0,R0）。
            // 连续 8 步即可判定为 NOP 海，立即模拟函数返回（PC←LR），防止
            // CPU 空转数千步直到 RUNAWAY 检测才被捕获。
            //
            // 阈值选择：
            //   - Sappy 初始化代码最多出现 3-4 步 MOVS R0,R0（正常填充）
            //   - IWRAM NOP 海最少 62 步（v9 日志实测）
            //   - 8 步阈值：足够区分正常代码与未初始化区域
            // -------------------------------------------------------
            if (!m_halted && m_regs.T())
            {
                uint16_t fetchedInstr = ReadHalf(currentInstrPC);
                if (fetchedInstr == 0x0000u)
                {
                    s_nopSeaCount++;
                    if (s_nopSeaCount == 8)
                    {
                        // 第一次触发时记录完整上下文
                        LogDebug(L"[CPU:NOP-SEA] 连续 %d 步 0x0000 at PC=0x%08X "
                                 L"R0=%08X R1=%08X R2=%08X R3=%08X "
                                 L"LR=%08X SP=%08X CPSR=%08X "
                                 L"IME=%d IE=0x%04X IF=0x%04X",
                                 s_nopSeaCount, currentInstrPC,
                                 m_regs.r[0], m_regs.r[1], m_regs.r[2], m_regs.r[3],
                                 m_regs.LR(), m_regs.SP(), m_regs.cpsr,
                                 (int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl);
                    }
                    if (s_nopSeaCount >= 8)
                    {
                        uint32_t lr = m_regs.LR();
                        LogDebug(L"[CPU:NOP-SEA] 注入空函数返回 LR=0x%08X (T=%d)，"
                                 L"跳出 NOP 海（已连续 %d 步）",
                                 lr, (int)((lr & 1u) != 0u), s_nopSeaCount);
                        uint32_t retTarget = lr & ~1u;
                        if (lr & 1u) { m_regs.SetT(true);  m_regs.PC() = retTarget + 4u; }
                        else         { m_regs.SetT(false); m_regs.PC() = retTarget + 8u; }
                        s_nopSeaCount = 0;
                        // 重新计算 currentInstrPC 以保证后续追踪正确（继续本循环体）
                        currentInstrPC = m_regs.PC() - (m_regs.T() ? 4u : 8u);
                    }
                }
                else
                {
                    if (s_nopSeaCount > 0)
                    {
                        // NOP-SEA 计数器重置，v16 关闭
                        // LogDebug(L"[CPU:NOP-SEA] 计数器重置（之前 %d 步，PC=0x%08X）", s_nopSeaCount, currentInstrPC);
                        s_nopSeaCount = 0;
                    }
                }
            }

            // -------------------------------------------------------
            // 调试：追踪 PC 在 0x08000500-0x080005FF 范围内的每条指令
            // 目的：观察 SoundDriverInit 完整执行流程及 PC=0x08000594 等待循环
            // 步数上限 600 步，覆盖完整初始化路径
            // -------------------------------------------------------
            if (!s_loopDone &&
                currentInstrPC >= 0x08000500u && currentInstrPC <= 0x080005FFu)
            {
                if (!s_loopTracking)
                {
                    s_loopTracking   = true;
                    s_loopTrackCount = 0;
                    // LogDebug(L"  [LoopTrace] 进入 0x08000500 追踪区域，开始追踪指令");
                }
                if (s_loopTrackCount < 600)
                {
                    uint16_t tinstr = ReadHalf(currentInstrPC);
                    // 记录指令及所有寄存器，方便分析等待条件
                   // LogDebug(L"  [LoopTrace+%03d] PC=0x%08X Instr=0x%04X "
                           //  L"R0=%08X R1=%08X R2=%08X R3=%08X R4=%08X R5=%08X R6=%08X R7=%08X "
                         //    L"R8=%08X R9=%08X R10=%08X R11=%08X R12=%08X "
                          //   L"LR=%08X SP=%08X IF=0x%04X IE=0x%04X IME=%d",
                          //   s_loopTrackCount, currentInstrPC, tinstr,
                             //m_regs.r[0], m_regs.r[1], m_regs.r[2], m_regs.r[3],
                            // m_regs.r[4], m_regs.r[5], m_regs.r[6], m_regs.r[7],
                            // m_regs.r[8], m_regs.r[9], m_regs.r[10], m_regs.r[11], m_regs.r[12],
                            // m_regs.LR(), m_regs.SP(),
                            // (int)m_irq.ifl, (int)m_irq.ie, (int)m_irq.ime);
                    s_loopTrackCount++;
                    if (s_loopTrackCount >= 600)
                    {
                        s_loopDone = true;
                        // 追踪结束时记录关键状态
                        //LogDebug(L"  [LoopTrace] 追踪完成(600步) "
                                 //L"IWRAM[0x03007FFC]=0x%08X IWRAM[0x03007FF8]=0x%04X "
                                // L"Timer3(en=%d reload=0x%04X) Timer2(en=%d reload=0x%04X) "
                                // L"IME=%d IE=0x%04X IF=0x%04X",
                                // ReadWord(0x03007FFC), (int)ReadHalf(0x03007FF8),
                                // (int)m_timers[3].enabled, m_timers[3].reload,
                                // (int)m_timers[2].enabled, m_timers[2].reload,
                                 //(int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl);
                    }
                }
            }

            // 检测从死循环出口（0x081DE39E）开始的路径
            if (!s_exitDone && !s_exitTracking && currentInstrPC == 0x081DE39Eu)
            {
                s_exitTracking   = true;
                s_exitTrackCount = 0;
                // LogDebug(L"  [ExitTrace] 游戏退出 VCOUNT 死循环，开始追踪后续 60 步执行路径");
            }
            if (!s_exitDone && s_exitTracking && s_exitTrackCount < 60)
            {
                uint32_t instr = m_regs.T() ? ReadHalf(currentInstrPC) : ReadWord(currentInstrPC);
                //LogDebug(L"  [ExitTrace+%02d] PC=0x%08X Instr=0x%08X T=%d R0=%08X R1=%08X R2=%08X R3=%08X R4=%08X R5=%08X R6=%08X R7=%08X LR=%08X SP=%08X",
                         //s_exitTrackCount, currentInstrPC, instr, (int)m_regs.T(),
                        // m_regs.r[0], m_regs.r[1], m_regs.r[2], m_regs.r[3],
                        // m_regs.r[4], m_regs.r[5], m_regs.r[6], m_regs.r[7],
                         //m_regs.LR(), m_regs.SP());
                s_exitTrackCount++;
                if (s_exitTrackCount >= 60)
                {
                    s_exitDone = true;
                    // LogDebug(L"  [ExitTrace] 追踪完成，IME=%d IE=0x%04X IF=0x%04X magicAddr=0x%08X", 
                             //(int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl, m_magicAddr);
                }
            }

            // -------------------------------------------------------
            // Bug #13 修复：SoundDriverInit 清零循环（内层 + 外层）强制退出
            //
            // 结构（第一组，双层循环）：
            //   外层 r4: 0→7，PC=0x08000588-0x0800059C
            //   内层 r1: 0→r3(≈33M)，PC=0x0800058E-0x08000596
            //
            // 策略：PC=0x08000594(CMP r1,r3) 且 r1>=0x200 时
            //   r1=r3+1 → 内层退出；r4=7 → ADD r4,#1→8, CMP r4,#7 不跳 → 外层退出
            // -------------------------------------------------------
            if (currentInstrPC == 0x08000594u && m_regs.r[1] >= 0x200u)
            {
                if (!s_loopEscapeDone)
                {
                    s_loopEscapeDone = true;
                    LogDebug(L"[LoopEscape] 强制退出清零循环(内层+外层): "
                             L"r1=0x%08X→r3+1=0x%08X  r4=0x%08X→7",
                             m_regs.r[1], m_regs.r[3] + 1u, m_regs.r[4]);
                    m_regs.r[4] = 7u;
                }
                m_regs.r[1] = m_regs.r[3] + 1u;
            }

            // -------------------------------------------------------
            // Bug #14 修复：第三层清零循环强制退出
            //
            // 结构（第二组，单层循环）：
            //   PC=0x080005AA-0x080005B2
            //   STRH r2,[r0]; ADD r0,#2; ADD r1,#1; CMP r1,#0xFF; BLS
            //
            // r3=ROM[0x0800072C]=0 → r0=0（写入 BIOS 区），需要逃逸
            // 策略：PC=0x080005B0(CMP r1,#0xFF) 且 r1>=0x20 → r1=0x100 退出
            // -------------------------------------------------------
            if (currentInstrPC == 0x080005B0u && m_regs.r[1] >= 0x20u)
            {
                if (!s_loop3EscapeDone)
                {
                    s_loop3EscapeDone = true;
                    LogDebug(L"[Loop3Escape] 强制退出第三层清零循环: "
                             L"r1=0x%02X→0x100  r0=0x%08X  r3=0x%08X  r4=0x%08X",
                             m_regs.r[1], m_regs.r[0], m_regs.r[3], m_regs.r[4]);
                }
                else
                {
                    LogDebug(L"[Loop3Escape] 第三层循环再次逃逸: r1=0x%02X r4=0x%08X",
                             m_regs.r[1], m_regs.r[4]);
                }
                m_regs.r[1] = 0x100u;  // r1(0x100) > #0xFF → BLS(C=1,Z=0) 不跳
            }

            // -------------------------------------------------------
            // 调试：完整清零循环退出后追踪 1500 步，定位 Timer3 初始化代码
            // 触发：PC 首次离开整个循环体区域（0x08000588-0x08000596）
            // -------------------------------------------------------
            {
                bool inFullLoop = (currentInstrPC >= 0x08000588u &&
                                   currentInstrPC <= 0x08000596u);
                if (!s_afterLoopDone && s_prevInFullLoop && !inFullLoop)
                {
                    s_afterLoopTracking = true;
                    s_afterLoopCount    = 0;
                    // LogDebug(L"[AfterLoop] 完整清零循环已退出，开始追踪后续 1500 步 首PC=0x%08X "
                            // L"IME=%d IE=0x%04X IF=0x%04X "
                             //L"Timer3(en=%d reload=0x%04X) r4=0x%08X",
                            // currentInstrPC,
                             //(int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl,
                             //(int)m_timers[3].enabled, m_timers[3].reload,
                             //m_regs.r[4]);
                }
                s_prevInFullLoop = inFullLoop;
            }
            if (!s_afterLoopDone && s_afterLoopTracking && s_afterLoopCount < 4000)
            {
                uint16_t tinstr = m_regs.T() ? ReadHalf(currentInstrPC) : 0xFFFFu;
                // LogDebug(L"[AfterLoop+%04d] PC=0x%08X Instr=0x%04X "
                         //L"R0=%08X R1=%08X R2=%08X R3=%08X "
                        // L"R4=%08X R5=%08X R6=%08X R7=%08X "
                        // L"R8=%08X R9=%08X R10=%08X R11=%08X R12=%08X "
                       //  L"LR=%08X SP=%08X IF=0x%04X IE=0x%04X IME=%d",
                        // s_afterLoopCount, currentInstrPC, tinstr,
                         //m_regs.r[0], m_regs.r[1], m_regs.r[2], m_regs.r[3],
                        // m_regs.r[4], m_regs.r[5], m_regs.r[6], m_regs.r[7],
                        // m_regs.r[8], m_regs.r[9], m_regs.r[10], m_regs.r[11], m_regs.r[12],
                         //m_regs.LR(), m_regs.SP(),
                         //(int)m_irq.ifl, (int)m_irq.ie, (int)m_irq.ime);
                s_afterLoopCount++;
                if (s_afterLoopCount >= 4000)
                {
                    s_afterLoopDone = true;
                    // LogDebug(L"[AfterLoop] 追踪完成(4000步) "
                            // L"Timer0(en=%d reload=0x%04X cnt=0x%04X) "
                            // L"Timer1(en=%d reload=0x%04X cnt=0x%04X) "
                             //L"Timer2(en=%d reload=0x%04X cnt=0x%04X) "
                            // L"Timer3(en=%d reload=0x%04X cnt=0x%04X) "
                             //L"IWRAM[0x7FFC]=0x%08X IME=%d IE=0x%04X IF=0x%04X",
                             //(int)m_timers[0].enabled, m_timers[0].reload, m_timers[0].counter,
                             //(int)m_timers[1].enabled, m_timers[1].reload, m_timers[1].counter,
                            // (int)m_timers[2].enabled, m_timers[2].reload, m_timers[2].counter,
                             //(int)m_timers[3].enabled, m_timers[3].reload, m_timers[3].counter,
                             //ReadWord(0x03007FFC),
                             //(int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl);
                }
            }

            // -------------------------------------------------------
            // 追踪3：PostReturn — SoundDriverInit 返回后 ROM 调用方执行路径
            // 触发：PC 首次进入 0x08054E28-0x08054F00（SoundDriverInit 调用方区域）
            // -------------------------------------------------------
            if (!s_postReturnDone)
            {
                bool inCallerRange = (currentInstrPC >= 0x08054E28u &&
                                      currentInstrPC <= 0x08054F00u);
                if (s_afterLoopDone && inCallerRange && !s_postReturnTracking)
                {
                    s_postReturnTracking = true;
                    s_postReturnCount    = 0;
                    // LogDebug(L"[PostReturn] SoundDriverInit 返回调用方，开始追踪600步 "
                            // L"PC=0x%08X IME=%d IE=0x%04X IF=0x%04X",
                             //currentInstrPC,
                             //(int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl);
                }
                if (s_postReturnTracking && s_postReturnCount < 600)
                {
                    uint16_t tinstr2 = m_regs.T() ? ReadHalf(currentInstrPC) : 0xFFFFu;
                    // LogDebug(L"[PostReturn+%03d] PC=0x%08X Instr=0x%04X "
                             //L"R0=%08X R1=%08X R2=%08X R3=%08X "
                             //L"R4=%08X R5=%08X R6=%08X R7=%08X "
                             //L"R8=%08X R9=%08X R10=%08X R11=%08X R12=%08X "
                             //L"LR=%08X SP=%08X IF=0x%04X IE=0x%04X IME=%d",
                            // s_postReturnCount, currentInstrPC, tinstr2,
                             //m_regs.r[0], m_regs.r[1], m_regs.r[2], m_regs.r[3],
                             //m_regs.r[4], m_regs.r[5], m_regs.r[6], m_regs.r[7],
                             //m_regs.r[8], m_regs.r[9], m_regs.r[10], m_regs.r[11], m_regs.r[12],
                             //m_regs.LR(), m_regs.SP(),
                             //(int)m_irq.ifl, (int)m_irq.ie, (int)m_irq.ime);
                    s_postReturnCount++;
                    if (s_postReturnCount >= 600)
                    {
                        s_postReturnDone = true;
                        // LogDebug(L"[PostReturn] 追踪完成(600步) "
                                // L"Timer0(en=%d reload=0x%04X) "
                                // L"Timer1(en=%d reload=0x%04X) "
                                // L"IME=%d IE=0x%04X IF=0x%04X",
                                // (int)m_timers[0].enabled, m_timers[0].reload,
                                 //(int)m_timers[1].enabled, m_timers[1].reload,
                                 //(int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl);
                    }
                }
            }

            // -------------------------------------------------------
            // 追踪4：IWRAMEntry — PC 首次跳入 IWRAM（0x03000000-0x03007FFF）
            // 捕获 Sappy 引擎入口的真实 PC 和状态
            // [v10] 扩展到 500 步；检测到连续 ≥4 步 0x0000 时提前结束追踪
            //       （NOP 海由 v10A/v10B 处理，不需要打印 500 行全零）
            // -------------------------------------------------------
            if (!s_iwramEntryDone)
            {
                bool inIwram = (currentInstrPC >= 0x03000000u &&
                                currentInstrPC <= 0x03007FFFu);
                if (inIwram && !s_iwramEntryTracking)
                {
                    s_iwramEntryTracking = true;
                    s_iwramEntryCount    = 0;
                    // LogDebug(L"[IWRAMEntry] PC 首次进入 IWRAM！开始追踪500步 "
                           //  L"PC=0x%08X lastPC=0x%08X IME=%d IE=0x%04X IF=0x%04X "
                           //  L"Timer0(en=%d reload=0x%04X cnt=0x%04X) "
                             //L"Timer1(en=%d reload=0x%04X cnt=0x%04X)",
                            // currentInstrPC, s_lastPC,
                            // (int)m_irq.ime, (int)m_irq.ie, (int)m_irq.ifl,
                            // (int)m_timers[0].enabled, m_timers[0].reload, m_timers[0].counter,
                            // (int)m_timers[1].enabled, m_timers[1].reload, m_timers[1].counter);
                }
                if (s_iwramEntryTracking && s_iwramEntryCount < 500)
                {
                    uint16_t tinstr3 = m_regs.T() ? ReadHalf(currentInstrPC) : 0xFFFFu;

                    // [v10] 连续 NOP 早退：避免打印数百行 0x0000
                    static int s_iwramNopCnt = 0;
                    if (tinstr3 == 0x0000u)
                    {
                        s_iwramNopCnt++;
                        if (s_iwramNopCnt == 4)
                        {
                            // LogDebug(L"[IWRAMEntry+%03d] NOP 海检出（连续 4 步 0x0000），"
                                     //L"PC=0x%08X LR=0x%08X — 提前结束追踪，"
                                   //  L"交由 v10A/v10B 处理跳出逻辑",
                                    // s_iwramEntryCount, currentInstrPC, m_regs.LR());
                            s_iwramEntryDone = true;
                            s_iwramNopCnt    = 0;
                            goto iwram_entry_done;
                        }
                    }
                    else
                    {
                        s_iwramNopCnt = 0;
                    }

                    // LogDebug(L"[IWRAMEntry+%03d] PC=0x%08X Instr=0x%04X "
                            // L"R0=%08X R1=%08X R2=%08X R3=%08X "
                            // L"R4=%08X R5=%08X R6=%08X R7=%08X "
                            // L"R8=%08X R9=%08X R10=%08X R11=%08X R12=%08X "
                            // L"LR=%08X SP=%08X",
                            // s_iwramEntryCount, currentInstrPC, tinstr3,
                             //m_regs.r[0], m_regs.r[1], m_regs.r[2], m_regs.r[3],
                             //m_regs.r[4], m_regs.r[5], m_regs.r[6], m_regs.r[7],
                             //m_regs.r[8], m_regs.r[9], m_regs.r[10], m_regs.r[11], m_regs.r[12],
                             //m_regs.LR(), m_regs.SP());
                    s_iwramEntryCount++;
                    if (s_iwramEntryCount >= 500)
                    {
                        s_iwramEntryDone = true;
                        // LogDebug(L"[IWRAMEntry] 追踪完成(500步) "
                                 //L"PC=0x%08X Timer0(en=%d reload=0x%04X cnt=0x%04X) "
                                // L"DMA1(en=%d) DMA2(en=%d)",
                                // currentInstrPC,
                                // (int)m_timers[0].enabled, m_timers[0].reload, m_timers[0].counter,
                                // (int)m_dma[1].enabled, (int)m_dma[2].enabled);
                    }
                    iwram_entry_done:;
                }
            }
            s_lastPC = currentInstrPC;

            if (m_regs.T())
                step = ExecuteThumb();
            else
                step = ExecuteArm();

            if (step <= 0) step = 1;

            // -----------------------------------------------------------
            // [v16] 异步注入哨兵检测
            // -----------------------------------------------------------
            if (s_injecting)
            {
                s_injectSteps++;
                // [v17 修复2] 注入步骤 PC 追踪：记录前 50 步的执行路径
                if (s_injectSteps <= 50) {
                    uint32_t tracePC = m_regs.PC() - (m_regs.T() ? 4u : 8u);
                    LogDebug(L"[v21:Step%02d] PC=0x%08X R0=0x%08X R1=0x%08X R2=0x%08X",
                             s_injectSteps, tracePC, m_regs.r[0], m_regs.r[1], m_regs.r[2]);
                }
                // [v18] Step10：记录候选 mplay 地址（R2 = BIOS预取值经 MOV R2,R0 赋值后的候选地址）
                // [v20] Step06：0x08002DB8 把 R1 从3覆盖为1，立即恢复 R1=3
                // 目的：使 Step15 CMP R0(=3),R1(=3) → Z=1 → BNE 不跳 → 执行 0x08002DCE
                if (s_injectSteps == 6) {
                    m_regs.r[1] = 3u;
                    LogDebug(L"[v21:Step06] R1 强制恢复=3（对抗 0x08002DB8 覆盖，使 BNE@0x08002DCC 不跳）");
                }
                if (s_injectSteps == 10) {
                    s_step10R2 = m_regs.r[2];
                    LogDebug(L"[v21:Step10] 候选mplay=0x%08X  magic@候选=0x%08X",
                             s_step10R2, ReadWord(s_step10R2));
                }
                // [v18] Step16：打印 CPSR（分析 0x08002DCC 条件跳转是否为 BNE/BGT）
                if (s_injectSteps == 16) {
                    uint32_t cpsr16 = m_regs.cpsr;
                    LogDebug(L"[v21:Step16] CPSR=0x%08X  N=%d Z=%d C=%d V=%d",
                             cpsr16,
                             (int)((cpsr16 >> 31u) & 1u),
                             (int)((cpsr16 >> 30u) & 1u),
                             (int)((cpsr16 >> 29u) & 1u),
                             (int)((cpsr16 >> 28u) & 1u));
                }
                // [v20] Step17 应为 PC=0x08002DCE（BNE修复后不跳），否则说明 R1 覆盖仍有效
                uint32_t execPC = m_regs.PC() - (m_regs.T() ? 4u : 8u);
                if ((execPC & ~1u) == 0x02000000u)
                {
                    s_injecting = false;
                    s_m4aInjected = true;   // [v21] 永久锁定，禁止后续 SoundDriverInit 再次触发注入
                    LogDebug(L"[v21] m4aOpenSong 异步执行完成（steps=%d），恢复原 CPU 上下文", s_injectSteps);

                    uint32_t sappyBase = ReadWord(0x03007FF0u);
                    LogDebug(L"[v21] 注入后 Sappy(@0x%08X): magic=0x%08X status=0x%02X",
                             sappyBase, ReadWord(sappyBase), ReadByte(sappyBase + 10u));
                    LogDebug(L"[v21] 注入后 songField=0x%08X ch0b0=0x%02X ch1b0=0x%02X ch2b0=0x%02X",
                             ReadWord(sappyBase + 8u),
                             ReadByte(sappyBase + 0x40u),
                             ReadByte(sappyBase + 0x40u + 0x40u),
                             ReadByte(sappyBase + 0x40u + 0x40u * 2u));
                    LogDebug(L"[v21] IWRAM[0x03000000] = 0x%08X（修复B'后）", ReadWord(0x03000000u));
                    if (s_step10R2 != 0u && (s_step10R2 >> 24) == 0x02u) {
                        LogDebug(L"[v21] 候选mplay@0x%08X: magic=0x%08X ch0@+40=0x%02X ch1@+80=0x%02X ch2@+C0=0x%02X",
                                 s_step10R2, ReadWord(s_step10R2),
                                 ReadByte(s_step10R2+0x40u), ReadByte(s_step10R2+0x80u), ReadByte(s_step10R2+0xC0u));
                        LogDebug(L"[v21] 候选mplay dump[00..1F]: %08X %08X %08X %08X %08X %08X %08X %08X",
                                 ReadWord(s_step10R2+0x00u), ReadWord(s_step10R2+0x04u),
                                 ReadWord(s_step10R2+0x08u), ReadWord(s_step10R2+0x0Cu),
                                 ReadWord(s_step10R2+0x10u), ReadWord(s_step10R2+0x14u),
                                 ReadWord(s_step10R2+0x18u), ReadWord(s_step10R2+0x1Cu));
                    }
                    LogDebug(L"[v21] sappyBase dump[00..1F] 注入后: %08X %08X %08X %08X %08X %08X %08X %08X",
                             ReadWord(sappyBase+0x00u), ReadWord(sappyBase+0x04u),
                             ReadWord(sappyBase+0x08u), ReadWord(sappyBase+0x0Cu),
                             ReadWord(sappyBase+0x10u), ReadWord(sappyBase+0x14u),
                             ReadWord(sappyBase+0x18u), ReadWord(sappyBase+0x1Cu));

                    // [v19] 读 sappyBase+0x1C 的固定真实 mplay 地址
                    {
                        uint32_t realMplay = ReadWord(sappyBase + 0x1Cu);
                        LogDebug(L"[v21] 真实mplay@sappyBase+0x1C=0x%08X: magic=0x%08X",
                                 realMplay, ReadWord(realMplay));
                        LogDebug(L"[v21] 真实mplay dump[00..1F]: %08X %08X %08X %08X %08X %08X %08X %08X",
                                 ReadWord(realMplay+0x00u), ReadWord(realMplay+0x04u),
                                 ReadWord(realMplay+0x08u), ReadWord(realMplay+0x0Cu),
                                 ReadWord(realMplay+0x10u), ReadWord(realMplay+0x14u),
                                 ReadWord(realMplay+0x18u), ReadWord(realMplay+0x1Cu));
                        LogDebug(L"[v21] 真实mplay channels: ch0@+0x40=0x%02X ch1@+0x80=0x%02X ch2@+0xC0=0x%02X",
                                 ReadByte(realMplay+0x40u), ReadByte(realMplay+0x80u), ReadByte(realMplay+0xC0u));
                    }
                    // 恢复原 CPU 上下文
                    m_regs.PC()  = s_savedPC;
                    m_regs.LR()  = s_savedLR;
                    m_regs.r[0]  = s_savedR0;
                     m_regs.r[2]  = s_savedR2;
                    m_regs.cpsr  = s_savedCPSR;
                    m_regs.spsr  = s_savedSPSR;
                    m_halted     = s_savedHalted;

                    LogDebug(L"[v21] 原 CPU 上下文已恢复: PC=0x%08X LR=0x%08X CPSR=0x%08X",
                             m_regs.PC(), m_regs.LR(), m_regs.cpsr);
                }
            }
        }
        else
        {
            step = 4; // CPU 暂停，推进时钟
        }

        m_cycleAccum   += step;
        cyclesThisCall += step;

        // 更新 VCOUNT：基于全局累积周期，跨帧连续，不受 cyclesToRun 整帧边界影响
        uint8_t vcount = (uint8_t)((m_cycleAccum / GBA_CYCLES_PER_LINE) % GBA_TOTAL_LINES);
        m_ioram[0x006] = vcount;
        m_ioram[0x007] = 0;

        // VBlank IRQ：VCOUNT 159→160 边沿触发
    if (vcount == GBA_VBLANK_LINE && m_lastVcount != GBA_VBLANK_LINE) {
            m_irq.ifl |= 0x0001; // bit0 = VBlank
            m_halted = false; // 强制唤醒
        }
        m_lastVcount = vcount;

        // 推进定时器
        TickTimers(step);

        // 处理中断
        HandleInterrupt();

        // 推进 APU，生成音频样本
        int16_t tempBuf[64];
        int newSamples = m_apu.Tick(step, tempBuf, 32);
        for (int i = 0; i < newSamples && samplesGenerated < maxSamples; i++)
        {
            buffer[samplesGenerated * 2]     = tempBuf[i * 2];
            buffer[samplesGenerated * 2 + 1] = tempBuf[i * 2 + 1];
            samplesGenerated++;
        }
    }

    // Frame 尾日志已验证正常，v16 关闭
    // if (m_frameCount < 10) { LogDebug(L"GbaEmulator::RunForSamples: Frame %d done ...", ...); }

    return samplesGenerated;
}

// ============================================================
// DMA 实现
// ============================================================

// 执行一次 DMA 传输
// Sound FIFO DMA（timing==3）：每次定时器溢出传输 4×32-bit = 16 字节到 FIFO
// 普通 DMA（timing==0 立即）：按 count 传输，完成后若 repeat=false 则禁用
void GbaEmulator::RunDma(int ch)
{
    GbaDma& d = m_dma[ch];
    if (!d.enabled) return;

    bool isFifoA = (d.dst == 0x040000A0u || d.dst_latch == 0x040000A0u);
    bool isFifoB = (d.dst == 0x040000A4u || d.dst_latch == 0x040000A4u);

    // DEBUG：DMA 传输节点（已验证正常，v16 关闭）
    // LogDebug(L"[DMA] RunDma ch%d: src=0x%08X dst=0x%08X count=%d word=%d timing=%d "
    //          L"repeat=%d isFifoA=%d isFifoB=%d fifoA_count=%d fifoB_count=%d", ...)

    if (d.timing == 3 && (isFifoA || isFifoB))
    {
        // Sound FIFO DMA：每次触发传输 4 个 32-bit 字（16 字节 PCM 数据）
        // 源地址自增，目标固定（FIFO 地址不变）
        DmaFifo& fifo = isFifoA ? m_apu.GetFifoA() : m_apu.GetFifoB();
        
        // GBA FIFO DMA 行为：count<=16 时 FIFO 发出 DMA request，触发此函数
        // NeedsRefill() 确保与硬件一致（仅在 FIFO 低水位时传输）
        if (fifo.NeedsRefill())
        {
            for (int i = 0; i < 4; i++)
            {
                uint32_t data = ReadWord(d.src_latch);
                // FIFO 推送日志已完成分析，v16 关闭
                // LogDebug(L"[FIFO] DMA Push ch%d word%d: src=0x%08X data=0x%08X", ch, i, d.src_latch, data);
                if (isFifoA) m_apu.WriteFifoA(data);
                else         m_apu.WriteFifoB(data);
                d.src_latch += 4;
            }
        }
        // Sound FIFO DMA 总是 repeat，不在此处禁用
    }
    else
    {
        // 通用 DMA（立即或 VBlank）
        int transferSize = d.word_size ? 4 : 2;
        int count        = d.count ? (int)(uint32_t)d.count : 0x10000;

        for (int i = 0; i < count; i++)
        {
            if (d.word_size)
                WriteWord(d.dst_latch, ReadWord(d.src_latch));
            else
                WriteHalf(d.dst_latch, (uint16_t)ReadHalf(d.src_latch));

            // 源地址控制
            if      (d.src_ctrl == 0) d.src_latch += transferSize;
            else if (d.src_ctrl == 1) d.src_latch -= transferSize;
            // src_ctrl==2: 固定，不变

            // 目标地址控制
            if      (d.dst_ctrl == 0 || d.dst_ctrl == 3) d.dst_latch += transferSize;
            else if (d.dst_ctrl == 1)                     d.dst_latch -= transferSize;
            // dst_ctrl==2: 固定，不变
        }

        if (!d.repeat)
        {
            d.enabled = false;
        }
        else
        {
            // repeat 时目标地址重载（dst_ctrl==3）
            if (d.dst_ctrl == 3) d.dst_latch = d.dst;
        }
    }
}

// 触发所有指定时序的 DMA 通道
void GbaEmulator::CheckDmaTiming(int timing)
{
    for (int i = 0; i < 4; i++)
    {
        if (m_dma[i].enabled && m_dma[i].timing == timing)
            RunDma(i);
    }
}

// ============================================================
// SWI 软件模拟（替代缺失的 GBA BIOS）
// GBA 常用 SWI 号（ARM 模式取 bits[23:16]，Thumb 模式取 bits[7:0]）
// ============================================================
bool GbaEmulator::HandleSWI(uint8_t id)
{
    switch (id)
    {
    // SWI 0x04: IntrWait — 等待指定中断
    // SWI 0x05: VBlankIntrWait — 等待 VBlank（游戏主循环节拍）
    //
    // -------------------------------------------------------
    // 关键修复：GBA BIOS 的 IntrWait/VBlankIntrWait 实现在 HALT 前
    // 会强制设置 REG_IME=1，以确保中断响应被激活。
    //
    // 游戏（Sappy driver）依赖此行为：它自己不会写 0x04000208=1，
    // 而是期望 BIOS SWI 来开启 IME，否则 IRQ 向量永远不跳，
    // VBlank callback（Sappy tick）永远不执行 → 完全静音。
    //
    // 真实 GBA BIOS IntrWait 伪代码：
    //   REG_IME = 1;           ← 此处修复添加
    //   if (r0) BIOS_IF &= ~r1;
    //   do { HALT; } while (!(BIOS_IF & r1));
    //   REG_IME = 0; (restore) ← 不需要模拟，游戏返回后会自行管理
    // -------------------------------------------------------
    case 0x04:
        // IntrWait(waitForNew, intrFlags)：R0=1时先清除 IF，R1=等待的中断掩码
        m_irq.ime = 1;  // BIOS 必须在 HALT 前开启 IME
        if (m_regs.r[0] != 0) {
            m_irq.ifl &= ~(uint16_t)m_regs.r[1]; // 清除目标中断标志
            // 同步清除 BIOS interrupt flags 镜像（IWRAM 0x03007FF8）
            uint16_t biosFlags = ReadHalf(0x03007FF8);
            WriteHalf(0x03007FF8, biosFlags & ~(uint16_t)m_regs.r[1]);
        }
        m_halted = true;
        LogDebug(L"[SWI] 0x04 IntrWait: IME=1, waitNew=%d mask=0x%04X, HALT",
                 (int)m_regs.r[0], (int)m_regs.r[1]);
        return true;

    case 0x05:
        // VBlankIntrWait：= IntrWait(1, 0x0001)，等待 VBlank（IF bit0）
        // BIOS 先设置 IME=1，再清除当前 VBlank 标志，然后 HALT
        m_irq.ime = 1;         // ← 核心修复：开启 IME，使 IRQ 向量可被调用
        m_irq.ifl &= ~0x0001u; // 清除 VBlank IF，确保等待下一帧
        // 同步清除 BIOS interrupt flags 镜像
        { uint16_t bf = ReadHalf(0x03007FF8); WriteHalf(0x03007FF8, bf & ~0x0001u); }
        m_halted = true;
        LogDebug(L"[SWI] 0x05 VBlankIntrWait: IME=1, HALT, cleared VBlank IF, IE=0x%04X IF=0x%04X",
                 (int)m_irq.ie, (int)m_irq.ifl);
        return true;

    // SWI 0x06: Div — 有符号整数除法
    // R0 = 被除数，R1 = 除数 → R0 = 商，R1 = 余数，R3 = |商|
    case 0x06:
        if (m_regs.r[1] != 0)
        {
            int32_t num = (int32_t)m_regs.r[0];
            int32_t den = (int32_t)m_regs.r[1];
            m_regs.r[0] = (uint32_t)(num / den);
            m_regs.r[1] = (uint32_t)(num % den);
            m_regs.r[3] = (uint32_t)std::abs(num / den);
        }
        return true;

    // SWI 0x07: DivARM — 同 Div 但参数顺序相反（R1/R0）
    case 0x07:
        if (m_regs.r[0] != 0)
        {
            int32_t num = (int32_t)m_regs.r[1];
            int32_t den = (int32_t)m_regs.r[0];
            m_regs.r[0] = (uint32_t)(num / den);
            m_regs.r[1] = (uint32_t)(num % den);
            m_regs.r[3] = (uint32_t)std::abs(num / den);
        }
        return true;

    // SWI 0x08: Sqrt — 整数平方根，结果在 R0（16-bit）
    case 0x08:
        m_regs.r[0] = (uint32_t)(uint16_t)(uint32_t)sqrtf((float)m_regs.r[0]);
        return true;

    // SWI 0x0B: CpuSet — 内存复制/填充（16-bit 或 32-bit 单元）
    // R0=src, R1=dst, R2=控制字 (bit24=fill, bit26=word, bits[20:0]=count)
    case 0x0B:
    {
        uint32_t src  = m_regs.r[0];
        uint32_t dst  = m_regs.r[1];
        uint32_t ctrl = m_regs.r[2];
        bool     fill = (ctrl >> 24) & 1;
        bool     word = (ctrl >> 26) & 1;
        uint32_t cnt  = ctrl & 0x1FFFFF;
        if (word)
        {
            uint32_t val = fill ? ReadWord(src) : 0;
            for (uint32_t i = 0; i < cnt; i++)
            {
                if (!fill) val = ReadWord(src + i * 4);
                WriteWord(dst + i * 4, val);
            }
        }
        else
        {
            uint16_t val = fill ? ReadHalf(src) : 0;
            for (uint32_t i = 0; i < cnt; i++)
            {
                if (!fill) val = ReadHalf(src + i * 2);
                WriteHalf(dst + i * 2, val);
            }
        }
        return true;
    }

    // SWI 0x0C: CpuFastSet — 快速内存复制/填充（32-bit 单元，8 的倍数）
    // R0=src, R1=dst, R2=控制字 (bit24=fill, bits[20:0]=count)
    case 0x0C:
    {
        uint32_t src  = m_regs.r[0];
        uint32_t dst  = m_regs.r[1];
        uint32_t ctrl = m_regs.r[2];
        bool     fill = (ctrl >> 24) & 1;
        uint32_t cnt  = ctrl & 0x1FFFFF;
        uint32_t val  = fill ? ReadWord(src) : 0;
        for (uint32_t i = 0; i < cnt; i++)
        {
            if (!fill) val = ReadWord(src + i * 4);
            WriteWord(dst + i * 4, val);
        }
        return true;
    }

    // SWI 0x00/0x01: SoftReset / RegisterRamReset — 忽略，避免破坏模拟器状态
    case 0x00:
    case 0x01:
        return true;

    default:
        // 未知 SWI：让调用方跳转 BIOS 向量（通常在全零 BIOS 下安全跳过）
        return false;
    }
}